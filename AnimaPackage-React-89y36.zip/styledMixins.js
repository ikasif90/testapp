import { css } from "styled-components";

export const RobotoNormalBlack16px = css`
  color: var(--black);
  font-family: var(--font-family-roboto);
  font-size: var(--font-size-m);
  font-weight: 400;
  font-style: normal;
`;

export const HelveticaRegularNormalAbsoluteZero1 = css`
  color: var(--absolute-zero);
  font-family: var(--font-family-helvetica-regular);
  font-size: var(--font-size-m);
  font-weight: 400;
  font-style: normal;
`;

export const RobotoBoldBlack16px = css`
  color: var(--black);
  font-family: var(--font-family-roboto);
  font-size: var(--font-size-m);
  font-weight: 700;
  font-style: normal;
`;

export const RobotoNormalDoveGray12px = css`
  color: var(--dove-gray);
  font-family: var(--font-family-roboto);
  font-size: var(--font-size-xs);
  font-weight: 400;
  font-style: normal;
`;

export const RobotoNormalWhite16px = css`
  color: var(--white);
  font-family: var(--font-family-roboto);
  font-size: var(--font-size-m);
  font-weight: 400;
  font-style: normal;
`;

export const HelveticaBoldBlack16px = css`
  color: var(--black);
  font-family: var(--font-family-helvetica-bold);
  font-size: var(--font-size-m);
  font-weight: 700;
  font-style: normal;
`;

export const RobotoNormalAbsoluteZero10px = css`
  color: var(--absolute-zero);
  font-family: var(--font-family-roboto);
  font-size: var(--font-size-xxs);
  font-weight: 400;
  font-style: normal;
`;

export const RobotoNormalEerieBlack14px = css`
  color: var(--eerie-black);
  font-family: var(--font-family-roboto);
  font-size: var(--font-size-s);
  font-weight: 400;
  font-style: normal;
`;

export const RobotoBoldDoveGray14px = css`
  color: var(--dove-gray);
  font-family: var(--font-family-roboto);
  font-size: var(--font-size-s);
  font-weight: 700;
  font-style: normal;
`;

export const RobotoBoldHunterGreen16px = css`
  color: var(--hunter-green);
  font-family: var(--font-family-roboto);
  font-size: var(--font-size-m);
  font-weight: 700;
  font-style: normal;
`;

export const RobotoMediumHunterGreen28px = css`
  color: var(--hunter-green);
  font-family: var(--font-family-roboto);
  font-size: var(--font-size-xl);
  font-weight: 500;
  font-style: normal;
`;
