
import { css } from "styled-components";
import React from "react";
import { Switch, BrowserRouter as Router, Route } from "react-router-dom";
import X1ACostTabPrimaryNav from "./components/X1ACostTabPrimaryNav";

function App() {
  return (
    <Router>
      <Switch>
        <Route path="/:path(|1a-cost-tab-primary-nav)">
          <X1ACostTabPrimaryNav {...x1ACostTabPrimaryNavData} />
        </Route>
      </Switch>
    </Router>
  );
}

export default App;
const paragraphTextTextScale1Data = {
    children: "Home",
};

const paragraphTextTextScale2Data = {
    children: "Users",
    className: "paragraph-text-text-scale-1",
};

const paragraphTextTextScale3Data = {
    children: "Ticket Management",
    className: "paragraph-text-text-scale-2",
};

const paragraphTextTextScale4Data = {
    children: "Knowledge Center",
    className: "paragraph-text-text-scale-3",
};

const globalNavIconsDONTCHANGEProfileAndIData = {
    name: "Robert Smith",
};

const paragraphTextTextScale32Data = {
    children: "Applications",
};

const paragraphTextTextScale5Data = {
    children: "Cost Management",
    className: "paragraph-text-text-scale-4",
};

const x01ComponentsButtonzPrimitivesLabelData = {
    children: "Switch VBU",
};

const x01ComponentsButtonzPrimitivesDeskt2Data = {
    x01ComponentsButtonzPrimitivesLabel: x01ComponentsButtonzPrimitivesLabelData,
};

const x01ComponentsButtonzPrimitivesDesktData = {
    x01ComponentsButtonzPrimitivesDeskt: x01ComponentsButtonzPrimitivesDeskt2Data,
};

const x01ComponentsButtonzPrimitivesMediuData = {
    x01ComponentsButtonzPrimitivesDeskt: x01ComponentsButtonzPrimitivesDesktData,
};

const x01ComponentsButton02MediumData = {
    x01ComponentsButtonzPrimitivesMediu: x01ComponentsButtonzPrimitivesMediuData,
};

const tabsSelectedData = {
    item: "Checks",
};

const tabsNormal1Data = {
    item: "Invoices",
};

const tabsNormal2Data = {
    item: "Deductions",
    className: "tab-normal-1",
};

const tabsNormal3Data = {
    item: "RTM",
    className: "tab-normal-2",
};

const tabsNormal4Data = {
    item: "Information",
    className: "tab-normal-3",
};

const tabsData = {
    rectangle69: "/img/rectangle-69@1x.png",
    tabsSelectedProps: tabsSelectedData,
    tabsNormal1Props: tabsNormal1Data,
    tabsNormal2Props: tabsNormal2Data,
    tabsNormal3Props: tabsNormal3Data,
    tabsNormal4Props: tabsNormal4Data,
};

const paragraphTextTextScale42Data = {
    children: "Instructions and Legal text here",
};

const largeTextIconData = {
    children: "Search",
};

const primitivesMasterSearchLargeData = {
    largeTextIconProps: largeTextIconData,
};

const standardSearchData = {
    primitivesMasterSearchLargeProps: primitivesMasterSearchLargeData,
};

const inputBaseData = {
    label: "Search Range",
    input: "Current Month",
};

const inputFieldData = {
    inputBaseProps: inputBaseData,
};

const primitivesmasterButtonData = {
    children: "Export",
};

const large2Data = {
    primitivesmasterButtonProps: primitivesmasterButtonData,
};

const dataTableComponentsRowBackgroundWhi2Data = {
    className: "data-table-component-1",
};

const dataTableComponentsRowBackgroundWhi3Data = {
    className: "data-table-component-2",
};

const dataTableComponentsRowBackgroundWhi4Data = {
    className: "data-table-component-3",
};

const dataTableComponentsRowBackgroundWhi5Data = {
    className: "data-table-component-4",
};

const dataTableComponentsRowBackgroundWhi6Data = {
    className: "data-table-component-5",
};

const dataTableComponentsRowBackgroundWhi7Data = {
    className: "data-table-component-6",
};

const dataTableComponentsRowBackgroundWhi8Data = {
    className: "data-table-component-7",
};

const dataTableComponentsRowBackgroundWhi9Data = {
    className: "data-table-component-8",
};

const dataTableComponentsRowBackgroundWhi10Data = {
    className: "data-table-component-9",
};

const dataTableComponentsRowBackgroundWhi11Data = {
    className: "data-table-component-10",
};

const dataTableComponentsRowBackgroundWhi12Data = {
    className: "data-table-component-11",
};

const x01ComponentsLinkzPrimitivesLabelsD21Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD220Data,
};

const x01ComponentsLinkzPrimitivesLabelsD1Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD21Data,
};

const x01ComponentsLinkzPrimitivesViewpor1Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD1Data,
};

const x01ComponentsLinkRegular1Data = {
    x01ComponentsLinkzPrimitivesViewpor: x01ComponentsLinkzPrimitivesViewpor1Data,
};

const x01ComponentsLinkzPrimitivesLabelsD22Data = {
    linkText: "987654",
};

const x01ComponentsLinkzPrimitivesLabelsD3Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD22Data,
};

const x01ComponentsLinkzPrimitivesViewpor2Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD3Data,
};

const x01ComponentsLinkRegular2Data = {
    className: "x01-components-link-regular-1",
    x01ComponentsLinkzPrimitivesViewpor: x01ComponentsLinkzPrimitivesViewpor2Data,
};

const x01ComponentsLinkzPrimitivesLabelsD23Data = {
    linkText: "234567",
};

const x01ComponentsLinkzPrimitivesLabelsD4Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD23Data,
};

const x01ComponentsLinkzPrimitivesViewpor3Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD4Data,
};

const x01ComponentsLinkRegular3Data = {
    className: "x01-components-link-regular-copy",
    x01ComponentsLinkzPrimitivesViewpor: x01ComponentsLinkzPrimitivesViewpor3Data,
};

const x01ComponentsLinkzPrimitivesLabelsD24Data = {
    linkText: "246897",
};

const x01ComponentsLinkzPrimitivesLabelsD5Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD24Data,
};

const x01ComponentsLinkzPrimitivesViewpor4Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD5Data,
};

const x01ComponentsLinkRegular4Data = {
    className: "x01-components-link-regular-copy-2",
    x01ComponentsLinkzPrimitivesViewpor: x01ComponentsLinkzPrimitivesViewpor4Data,
};

const x01ComponentsLinkzPrimitivesLabelsD25Data = {
    linkText: "982346",
};

const x01ComponentsLinkzPrimitivesLabelsD6Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD25Data,
};

const x01ComponentsLinkzPrimitivesViewpor5Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD6Data,
};

const x01ComponentsLinkRegular5Data = {
    className: "x01-components-link-regular-copy-3",
    x01ComponentsLinkzPrimitivesViewpor: x01ComponentsLinkzPrimitivesViewpor5Data,
};

const x01ComponentsLinkzPrimitivesLabelsD26Data = {
    linkText: "238751",
};

const x01ComponentsLinkzPrimitivesLabelsD7Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD26Data,
};

const x01ComponentsLinkzPrimitivesViewpor6Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD7Data,
};

const x01ComponentsLinkRegular6Data = {
    className: "x01-components-link-regular-copy-4",
    x01ComponentsLinkzPrimitivesViewpor: x01ComponentsLinkzPrimitivesViewpor6Data,
};

const x01ComponentsLinkzPrimitivesLabelsD27Data = {
    linkText: "982375",
};

const x01ComponentsLinkzPrimitivesLabelsD8Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD27Data,
};

const x01ComponentsLinkzPrimitivesViewpor7Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD8Data,
};

const x01ComponentsLinkRegular7Data = {
    className: "x01-components-link-regular-copy-5",
    x01ComponentsLinkzPrimitivesViewpor: x01ComponentsLinkzPrimitivesViewpor7Data,
};

const x01ComponentsLinkzPrimitivesLabelsD28Data = {
    linkText: "654567",
};

const x01ComponentsLinkzPrimitivesLabelsD9Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD28Data,
};

const x01ComponentsLinkzPrimitivesViewpor8Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD9Data,
};

const x01ComponentsLinkRegular8Data = {
    className: "x01-components-link-regular-copy-6",
    x01ComponentsLinkzPrimitivesViewpor: x01ComponentsLinkzPrimitivesViewpor8Data,
};

const x01ComponentsLinkzPrimitivesLabelsD29Data = {
    linkText: "245432",
};

const x01ComponentsLinkzPrimitivesLabelsD10Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD29Data,
};

const x01ComponentsLinkzPrimitivesViewpor9Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD10Data,
};

const x01ComponentsLinkRegular9Data = {
    className: "x01-components-link-regular-copy-7",
    x01ComponentsLinkzPrimitivesViewpor: x01ComponentsLinkzPrimitivesViewpor9Data,
};

const x01ComponentsLinkzPrimitivesLabelsD210Data = {
    linkText: "761234",
};

const x01ComponentsLinkzPrimitivesLabelsD11Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD210Data,
};

const x01ComponentsLinkzPrimitivesViewpor10Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD11Data,
};

const x01ComponentsLinkRegular10Data = {
    className: "x01-components-link-regular-copy-8",
    x01ComponentsLinkzPrimitivesViewpor: x01ComponentsLinkzPrimitivesViewpor10Data,
};

const group81Data = {
    x01ComponentsLinkRegular1Props: x01ComponentsLinkRegular1Data,
    x01ComponentsLinkRegular2Props: x01ComponentsLinkRegular2Data,
    x01ComponentsLinkRegular3Props: x01ComponentsLinkRegular3Data,
    x01ComponentsLinkRegular4Props: x01ComponentsLinkRegular4Data,
    x01ComponentsLinkRegular5Props: x01ComponentsLinkRegular5Data,
    x01ComponentsLinkRegular6Props: x01ComponentsLinkRegular6Data,
    x01ComponentsLinkRegular7Props: x01ComponentsLinkRegular7Data,
    x01ComponentsLinkRegular8Props: x01ComponentsLinkRegular8Data,
    x01ComponentsLinkRegular9Props: x01ComponentsLinkRegular9Data,
    x01ComponentsLinkRegular10Props: x01ComponentsLinkRegular10Data,
};

const x01ComponentsLinkzPrimitivesLabelsD211Data = {
    linkText: "654321",
};

const x01ComponentsLinkzPrimitivesLabelsD12Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD211Data,
};

const x01ComponentsLinkzPrimitivesViewpor11Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD12Data,
};

const x01ComponentsLinkRegular11Data = {
    x01ComponentsLinkzPrimitivesViewpor: x01ComponentsLinkzPrimitivesViewpor11Data,
};

const x01ComponentsLinkzPrimitivesLabelsD212Data = {
    linkText: "987654",
};

const x01ComponentsLinkzPrimitivesLabelsD13Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD212Data,
};

const x01ComponentsLinkzPrimitivesViewpor12Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD13Data,
};

const x01ComponentsLinkRegular12Data = {
    className: "x01-components-link-regular-3",
    x01ComponentsLinkzPrimitivesViewpor: x01ComponentsLinkzPrimitivesViewpor12Data,
};

const x01ComponentsLinkzPrimitivesLabelsD213Data = {
    linkText: "234567",
};

const x01ComponentsLinkzPrimitivesLabelsD14Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD213Data,
};

const x01ComponentsLinkzPrimitivesViewpor13Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD14Data,
};

const x01ComponentsLinkRegular13Data = {
    className: "x01-components-link-regular-copy-1",
    x01ComponentsLinkzPrimitivesViewpor: x01ComponentsLinkzPrimitivesViewpor13Data,
};

const x01ComponentsLinkzPrimitivesLabelsD214Data = {
    linkText: "246897",
};

const x01ComponentsLinkzPrimitivesLabelsD15Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD214Data,
};

const x01ComponentsLinkzPrimitivesViewpor14Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD15Data,
};

const x01ComponentsLinkRegular14Data = {
    className: "x01-components-link-regular-copy-2-1",
    x01ComponentsLinkzPrimitivesViewpor: x01ComponentsLinkzPrimitivesViewpor14Data,
};

const x01ComponentsLinkzPrimitivesLabelsD215Data = {
    linkText: "982346",
};

const x01ComponentsLinkzPrimitivesLabelsD16Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD215Data,
};

const x01ComponentsLinkzPrimitivesViewpor15Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD16Data,
};

const x01ComponentsLinkRegular15Data = {
    className: "x01-components-link-regular-copy-3-1",
    x01ComponentsLinkzPrimitivesViewpor: x01ComponentsLinkzPrimitivesViewpor15Data,
};

const x01ComponentsLinkzPrimitivesLabelsD216Data = {
    linkText: "238751",
};

const x01ComponentsLinkzPrimitivesLabelsD17Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD216Data,
};

const x01ComponentsLinkzPrimitivesViewpor16Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD17Data,
};

const x01ComponentsLinkRegular16Data = {
    className: "x01-components-link-regular-copy-4-1",
    x01ComponentsLinkzPrimitivesViewpor: x01ComponentsLinkzPrimitivesViewpor16Data,
};

const x01ComponentsLinkzPrimitivesLabelsD217Data = {
    linkText: "982375",
};

const x01ComponentsLinkzPrimitivesLabelsD18Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD217Data,
};

const x01ComponentsLinkzPrimitivesViewpor17Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD18Data,
};

const x01ComponentsLinkRegular17Data = {
    className: "x01-components-link-regular-copy-5-1",
    x01ComponentsLinkzPrimitivesViewpor: x01ComponentsLinkzPrimitivesViewpor17Data,
};

const x01ComponentsLinkzPrimitivesLabelsD218Data = {
    linkText: "654567",
};

const x01ComponentsLinkzPrimitivesLabelsD19Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD218Data,
};

const x01ComponentsLinkzPrimitivesViewpor18Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD19Data,
};

const x01ComponentsLinkRegular18Data = {
    className: "x01-components-link-regular-copy-6-1",
    x01ComponentsLinkzPrimitivesViewpor: x01ComponentsLinkzPrimitivesViewpor18Data,
};

const x01ComponentsLinkzPrimitivesLabelsD219Data = {
    linkText: "245432",
};

const x01ComponentsLinkzPrimitivesLabelsD20Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD219Data,
};

const x01ComponentsLinkzPrimitivesViewpor19Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD20Data,
};

const x01ComponentsLinkRegular19Data = {
    className: "x01-components-link-regular-copy-7-1",
    x01ComponentsLinkzPrimitivesViewpor: x01ComponentsLinkzPrimitivesViewpor19Data,
};

const x01ComponentsLinkzPrimitivesLabelsD220Data = {
    linkText: "761234",
};

const x01ComponentsLinkzPrimitivesViewpor20Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD21Data,
};

const x01ComponentsLinkRegular20Data = {
    className: "x01-components-link-regular-copy-8-1",
    x01ComponentsLinkzPrimitivesViewpor: x01ComponentsLinkzPrimitivesViewpor20Data,
};

const group82Data = {
    x01ComponentsLinkRegular1Props: x01ComponentsLinkRegular11Data,
    x01ComponentsLinkRegular2Props: x01ComponentsLinkRegular12Data,
    x01ComponentsLinkRegular3Props: x01ComponentsLinkRegular13Data,
    x01ComponentsLinkRegular4Props: x01ComponentsLinkRegular14Data,
    x01ComponentsLinkRegular5Props: x01ComponentsLinkRegular15Data,
    x01ComponentsLinkRegular6Props: x01ComponentsLinkRegular16Data,
    x01ComponentsLinkRegular7Props: x01ComponentsLinkRegular17Data,
    x01ComponentsLinkRegular8Props: x01ComponentsLinkRegular18Data,
    x01ComponentsLinkRegular9Props: x01ComponentsLinkRegular19Data,
    x01ComponentsLinkRegular10Props: x01ComponentsLinkRegular20Data,
};

const x01ComponentsLinkzPrimitivesLabelsD221Data = {
    linkText: "654321",
};

const x01ComponentsLinkzPrimitivesLabelsD30Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD221Data,
};

const x01ComponentsLinkzPrimitivesViewpor21Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD30Data,
};

const x01ComponentsLinkRegular21Data = {
    x01ComponentsLinkzPrimitivesViewpor: x01ComponentsLinkzPrimitivesViewpor21Data,
};

const x01ComponentsLinkzPrimitivesLabelsD222Data = {
    linkText: "987654",
};

const x01ComponentsLinkzPrimitivesLabelsD31Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD222Data,
};

const x01ComponentsLinkzPrimitivesViewpor22Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD31Data,
};

const x01ComponentsLinkRegular22Data = {
    className: "x01-components-link-regular-4",
    x01ComponentsLinkzPrimitivesViewpor: x01ComponentsLinkzPrimitivesViewpor22Data,
};

const x01ComponentsLinkzPrimitivesLabelsD223Data = {
    linkText: "234567",
};

const x01ComponentsLinkzPrimitivesLabelsD32Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD223Data,
};

const x01ComponentsLinkzPrimitivesViewpor23Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD32Data,
};

const x01ComponentsLinkRegular23Data = {
    className: "x01-components-link-regular-copy-9",
    x01ComponentsLinkzPrimitivesViewpor: x01ComponentsLinkzPrimitivesViewpor23Data,
};

const x01ComponentsLinkzPrimitivesLabelsD224Data = {
    linkText: "246897",
};

const x01ComponentsLinkzPrimitivesLabelsD33Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD224Data,
};

const x01ComponentsLinkzPrimitivesViewpor24Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD33Data,
};

const x01ComponentsLinkRegular24Data = {
    className: "x01-components-link-regular-copy-2-2",
    x01ComponentsLinkzPrimitivesViewpor: x01ComponentsLinkzPrimitivesViewpor24Data,
};

const x01ComponentsLinkzPrimitivesLabelsD225Data = {
    linkText: "982346",
};

const x01ComponentsLinkzPrimitivesLabelsD34Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD225Data,
};

const x01ComponentsLinkzPrimitivesViewpor25Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD34Data,
};

const x01ComponentsLinkRegular25Data = {
    className: "x01-components-link-regular-copy-3-2",
    x01ComponentsLinkzPrimitivesViewpor: x01ComponentsLinkzPrimitivesViewpor25Data,
};

const x01ComponentsLinkzPrimitivesLabelsD226Data = {
    linkText: "238751",
};

const x01ComponentsLinkzPrimitivesLabelsD35Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD226Data,
};

const x01ComponentsLinkzPrimitivesViewpor26Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD35Data,
};

const x01ComponentsLinkRegular26Data = {
    className: "x01-components-link-regular-copy-4-2",
    x01ComponentsLinkzPrimitivesViewpor: x01ComponentsLinkzPrimitivesViewpor26Data,
};

const x01ComponentsLinkzPrimitivesLabelsD227Data = {
    linkText: "982375",
};

const x01ComponentsLinkzPrimitivesLabelsD36Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD227Data,
};

const x01ComponentsLinkzPrimitivesViewpor27Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD36Data,
};

const x01ComponentsLinkRegular27Data = {
    className: "x01-components-link-regular-copy-5-2",
    x01ComponentsLinkzPrimitivesViewpor: x01ComponentsLinkzPrimitivesViewpor27Data,
};

const x01ComponentsLinkzPrimitivesLabelsD228Data = {
    linkText: "654567",
};

const x01ComponentsLinkzPrimitivesLabelsD37Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD228Data,
};

const x01ComponentsLinkzPrimitivesViewpor28Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD37Data,
};

const x01ComponentsLinkRegular28Data = {
    className: "x01-components-link-regular-copy-6-2",
    x01ComponentsLinkzPrimitivesViewpor: x01ComponentsLinkzPrimitivesViewpor28Data,
};

const x01ComponentsLinkzPrimitivesLabelsD229Data = {
    linkText: "245432",
};

const x01ComponentsLinkzPrimitivesLabelsD38Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD229Data,
};

const x01ComponentsLinkzPrimitivesViewpor29Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD38Data,
};

const x01ComponentsLinkRegular29Data = {
    className: "x01-components-link-regular-copy-7-2",
    x01ComponentsLinkzPrimitivesViewpor: x01ComponentsLinkzPrimitivesViewpor29Data,
};

const x01ComponentsLinkzPrimitivesLabelsD230Data = {
    linkText: "761234",
};

const x01ComponentsLinkzPrimitivesLabelsD39Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD230Data,
};

const x01ComponentsLinkzPrimitivesViewpor30Data = {
    x01ComponentsLinkzPrimitivesLabelsD: x01ComponentsLinkzPrimitivesLabelsD39Data,
};

const x01ComponentsLinkRegular30Data = {
    className: "x01-components-link-regular-copy-8-2",
    x01ComponentsLinkzPrimitivesViewpor: x01ComponentsLinkzPrimitivesViewpor30Data,
};

const dataTableComponentsRowBackgroundWhi13Data = {
    className: "data-table-component-12",
};

const dataTableComponentsPaginationRowsPeData = {
    number: "10",
};

const dataTableComponentsFilterChipStep4Data = {
    chipTitle: "Title 1",
    filterSearch1: "Filter Search 1",
};

const dataTableComponentsFilterFullData = {
    dataTableComponentsFilterChipStep4P: dataTableComponentsFilterChipStep4Data,
};

const dataTablePaginationNumberOfPagesData = {
    children: "1-10 of 100",
};

const dataTablePaginationButtonActive1Data = {
    children: "First",
};

const dataTablePaginationButtonActive2Data = {
    children: "Next",
    className: "data-table-pagination-button-2",
};

const dataTablePaginationPageNumberInacti1Data = {
    children: "1",
};

const dataTablePaginationPageNumberInacti2Data = {
    children: "2",
};

const dataTablePaginationPageNumberInacti3Data = {
    children: "3",
};

const dataTablePaginationPageNumberInacti4Data = {
    children: "4",
};

const dataTablePaginationPageNumberInacti5Data = {
    children: "5",
};

const dataTablePaginationButtonActive3Data = {
    children: "Pre",
    className: "data-table-pagination-button-3",
};

const dataTablePaginationButtonActive4Data = {
    children: "Last",
    className: "data-table-pagination-button-4",
};

const dataTablePaginationData = {
    dataTablePaginationNumberOfPagesPro: dataTablePaginationNumberOfPagesData,
    dataTablePaginationButtonActive1Pro: dataTablePaginationButtonActive1Data,
    dataTablePaginationButtonActive2Pro: dataTablePaginationButtonActive2Data,
    dataTablePaginationPageNumberInacti: dataTablePaginationPageNumberInacti1Data,
    dataTablePaginationPageNumberInacti2: dataTablePaginationPageNumberInacti2Data,
    dataTablePaginationPageNumberInacti3: dataTablePaginationPageNumberInacti3Data,
    dataTablePaginationPageNumberInacti4: dataTablePaginationPageNumberInacti4Data,
    dataTablePaginationPageNumberInacti5: dataTablePaginationPageNumberInacti5Data,
    dataTablePaginationButtonActive3Pro: dataTablePaginationButtonActive3Data,
    dataTablePaginationButtonActive4Pro: dataTablePaginationButtonActive4Data,
};

const x1ACostTabPrimaryNavData = {
    homeOfficeVbu: "HOME OFFICE VBU",
    phone: "456789",
    programType: "PROGRAM TYPE",
    dropShip: "Drop-Ship",
    welcome: "Welcome!",
    title: "Curtain Pro, LLC",
    helperText: "",
    applications: "Vendor Finance Tools",
    costChangeRequests1: "Search Checks",
    costChangeRequests2: "Cost Change Requests",
    requestName: "Invoice Number",
    request: "Paid Amount",
    x0123445671: "$99,999.99",
    x133450561: "$99,999.99",
    x234245761: "$99,999.99",
    x234345701: "$99,999.99",
    x123499501: "$99,999.99",
    x0123445672: "$99,999.99",
    x133450562: "$99,999.99",
    x234245762: "$99,999.99",
    x234345702: "$99,999.99",
    x123499502: "$99,999.99",
    dateSubmitted: "Check Date",
    date1: "06/15/2021",
    date2: "06/08/2021",
    date3: "02/04/2021",
    date4: "01/15/2021",
    date5: "01/15/2021",
    date6: "06/15/2021",
    date7: "01/15/2021",
    date8: "06/08/2021",
    date9: "02/04/2021",
    date10: "01/15/2021",
    v2ArrowDown4: "/img/v2-arrow-down@2x.png",
    itemType: "Invoice Amount",
    sosOnline1: "$99,999.99",
    sosOnline2: "$99,999.99",
    stock1: "$99,999.99",
    stock2: "$99,999.99",
    stock3: "$99,999.99",
    sosOnline3: "$99,999.99",
    sosOnline4: "$99,999.99",
    stock4: "$99,999.99",
    sosOnline5: "$99,999.99",
    sosOnline6: "$99,999.99",
    locationType: "Invoice Count",
    onlineOnly1: "3456",
    stock5: "12",
    stock6: "300",
    onlineOnly2: "123",
    stock7: "33",
    stock8: "65",
    onlineOnly3: "221",
    onlineOnly4: "6",
    stock9: "2",
    stock10: "23",
    draft1: "1933",
    draft2: "1933",
    draft3: "1933",
    draft4: "1933",
    submitted1: "1933",
    submitted2: "1933",
    submitted3: "1933",
    submitted4: "1933",
    submitted5: "1933",
    submitted6: "1933",
    status: "Remit to Vendor",
    paragraphTextTextScale1Props: paragraphTextTextScale1Data,
    paragraphTextTextScale2Props: paragraphTextTextScale2Data,
    paragraphTextTextScale3Props: paragraphTextTextScale3Data,
    paragraphTextTextScale4Props: paragraphTextTextScale4Data,
    globalNavIconsDONTCHANGEProfileAndI: globalNavIconsDONTCHANGEProfileAndIData,
    paragraphTextTextScale3Props2: paragraphTextTextScale32Data,
    paragraphTextTextScale5Props: paragraphTextTextScale5Data,
    x01ComponentsButton02MediumProps: x01ComponentsButton02MediumData,
    tabsProps: tabsData,
    paragraphTextTextScale4Props2: paragraphTextTextScale42Data,
    standardSearchProps: standardSearchData,
    inputFieldProps: inputFieldData,
    large2Props: large2Data,
    dataTableComponentsRowBackgroundWhi: dataTableComponentsRowBackgroundWhi2Data,
    dataTableComponentsRowBackgroundWhi2: dataTableComponentsRowBackgroundWhi3Data,
    dataTableComponentsRowBackgroundWhi3: dataTableComponentsRowBackgroundWhi4Data,
    dataTableComponentsRowBackgroundWhi4: dataTableComponentsRowBackgroundWhi5Data,
    dataTableComponentsRowBackgroundWhi5: dataTableComponentsRowBackgroundWhi6Data,
    dataTableComponentsRowBackgroundWhi6: dataTableComponentsRowBackgroundWhi7Data,
    dataTableComponentsRowBackgroundWhi7: dataTableComponentsRowBackgroundWhi8Data,
    dataTableComponentsRowBackgroundWhi8: dataTableComponentsRowBackgroundWhi9Data,
    dataTableComponentsRowBackgroundWhi9: dataTableComponentsRowBackgroundWhi10Data,
    dataTableComponentsRowBackgroundWhi10: dataTableComponentsRowBackgroundWhi11Data,
    dataTableComponentsRowBackgroundWhi11: dataTableComponentsRowBackgroundWhi12Data,
    group81Props: group81Data,
    group82Props: group82Data,
    x01ComponentsLinkRegular1Props: x01ComponentsLinkRegular21Data,
    x01ComponentsLinkRegular2Props: x01ComponentsLinkRegular22Data,
    x01ComponentsLinkRegular3Props: x01ComponentsLinkRegular23Data,
    x01ComponentsLinkRegular4Props: x01ComponentsLinkRegular24Data,
    x01ComponentsLinkRegular5Props: x01ComponentsLinkRegular25Data,
    x01ComponentsLinkRegular6Props: x01ComponentsLinkRegular26Data,
    x01ComponentsLinkRegular7Props: x01ComponentsLinkRegular27Data,
    x01ComponentsLinkRegular8Props: x01ComponentsLinkRegular28Data,
    x01ComponentsLinkRegular9Props: x01ComponentsLinkRegular29Data,
    x01ComponentsLinkRegular10Props: x01ComponentsLinkRegular30Data,
    dataTableComponentsRowBackgroundWhi12: dataTableComponentsRowBackgroundWhi13Data,
    dataTableComponentsPaginationRowsPe: dataTableComponentsPaginationRowsPeData,
    dataTableComponentsFilterFullProps: dataTableComponentsFilterFullData,
    dataTablePaginationProps: dataTablePaginationData,
};

