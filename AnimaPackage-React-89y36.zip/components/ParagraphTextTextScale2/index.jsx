import React from "react";
import styled from "styled-components";


function ParagraphTextTextScale2() {
  return <ParagraphTextTextScale></ParagraphTextTextScale>;
}

const ParagraphTextTextScale = styled.div`
  display: flex;
  margin-left: 34px;
  margin-bottom: 3px;
  width: 134px;
  height: 23px;
  align-items: flex-start;
  gap: 10px;
  border: 1px none;
`;

export default ParagraphTextTextScale2;
