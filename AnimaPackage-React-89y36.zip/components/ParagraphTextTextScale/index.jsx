import React from "react";
import styled from "styled-components";
import { RobotoNormalWhite16px } from "../../styledMixins";


function ParagraphTextTextScale(props) {
  const { children, className } = props;

  return (
    <ParagraphTextTextScale1 className={`paragraph-text-text-scale ${className || ""}`}>
      <Body1 className="body-1">{children}</Body1>
    </ParagraphTextTextScale1>
  );
}

const ParagraphTextTextScale1 = styled.div`
  display: flex;
  margin-left: 14px;
  margin-bottom: 4px;
  width: 50px;
  align-items: flex-start;
  gap: 10px;
  border: 1px none;

  &.paragraph-text-text-scale.paragraph-text-text-scale-1 {
    margin-left: 20px;
    margin-bottom: 3px;
    width: 42px;
    height: 23px;
  }

  &.paragraph-text-text-scale.paragraph-text-text-scale-2 {
    margin-left: 33px;
    margin-bottom: 3px;
    width: 148px;
    height: 23px;
  }

  &.paragraph-text-text-scale.paragraph-text-text-scale-3 {
    margin-left: 34px;
    margin-bottom: 3px;
    width: 134px;
    height: 23px;
  }

  &.paragraph-text-text-scale.paragraph-text-text-scale-4 {
    width: 143px;
    height: 96px;
    position: absolute;
    top: 63px;
    left: 679px;
    margin-left: unset;
    margin-bottom: unset;
  }
`;

const Body1 = styled.div`
  ${RobotoNormalWhite16px}
  flex: 1;
  margin-top: -1px;
  letter-spacing: 0.24px;
  line-height: 24px;
  white-space: nowrap;
`;

export default ParagraphTextTextScale;
