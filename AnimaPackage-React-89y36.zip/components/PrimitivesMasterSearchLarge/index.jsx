import React from "react";
import NonFloated from "../NonFloated";
import LargeTextIcon from "../LargeTextIcon";
import IconButton from "../IconButton";
import styled from "styled-components";


function PrimitivesMasterSearchLarge(props) {
  const { largeTextIconProps } = props;

  return (
    <Primitive>
      <Primitive>
        <Input>
          <OverlapGroup>
            <NonFloated />
            <InnerContent>
              <PrefixPlaceholderText>
                <LargeTextIcon>{largeTextIconProps.children}</LargeTextIcon>
              </PrefixPlaceholderText>
              <RightSideIcons>
                <IconButton />
              </RightSideIcons>
            </InnerContent>
          </OverlapGroup>
        </Input>
      </Primitive>
    </Primitive>
  );
}

const Primitive = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  align-self: stretch;
  border: 1px none;
`;

const Input = styled.div`
  align-self: stretch;
  min-width: 515px;
  height: 56px;
`;

const OverlapGroup = styled.div`
  position: relative;
  width: 515px;
  height: 56px;
  border-radius: 8px;
`;

const InnerContent = styled.div`
  display: flex;
  width: 515px;
  height: 49px;
  align-items: center;
  justify-content: space-between;
  position: absolute;
  top: 4px;
  left: 0;
  border: 1px none;
`;

const PrefixPlaceholderText = styled.div`
  display: flex;
  width: fit-content;
  height: 48px;
  align-items: center;
  gap: 16px;
  padding: 0px 0px 0px 16px;
  position: relative;
  border: 1px none;
`;

const RightSideIcons = styled.div`
  display: flex;
  width: fit-content;
  align-items: center;
  justify-content: flex-end;
  padding: 0px 4px 0px 0px;
  position: relative;
  border: 1px none;
`;

export default PrimitivesMasterSearchLarge;
