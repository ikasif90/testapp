import React from "react";
import PrimitivesMasterSearchLarge from "../PrimitivesMasterSearchLarge";
import styled from "styled-components";


function StandardSearch(props) {
  const { primitivesMasterSearchLargeProps } = props;

  return (
    <StandardSearch1>
      <PrimitivesMasterSearchLarge largeTextIconProps={primitivesMasterSearchLargeProps.largeTextIconProps} />
    </StandardSearch1>
  );
}

const StandardSearch1 = styled.div`
  display: flex;
  position: relative;
  flex-direction: column;
  width: 515px;
  align-items: flex-start;
  gap: 10px;
  border: 1px none;
`;

export default StandardSearch;
