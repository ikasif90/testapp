import React from "react";
import styled from "styled-components";
import { RobotoNormalDoveGray12px } from "../../styledMixins";


function DataTablePaginationPageNumberInacti(props) {
  const { children } = props;

  return (
    <DataTablePaginationPageNumber1Inact>
      <Number>{children}</Number>
    </DataTablePaginationPageNumber1Inact>
  );
}

const DataTablePaginationPageNumber1Inact = styled.div`
  height: 20px;
  margin-left: 16px;
  display: flex;
  align-items: flex-start;
  min-width: 7px;
  border: 0px none;
`;

const Number = styled.div`
  ${RobotoNormalDoveGray12px}
  min-height: 20px;
  letter-spacing: 0;
  line-height: 20px;
  white-space: nowrap;
`;

export default DataTablePaginationPageNumberInacti;
