import React from "react";
import TabsSelected from "../TabsSelected";
import TabsNormal from "../TabsNormal";
import styled from "styled-components";


function Tabs(props) {
  const {
    rectangle69,
    tabsSelectedProps,
    tabsNormal1Props,
    tabsNormal2Props,
    tabsNormal3Props,
    tabsNormal4Props,
  } = props;

  return (
    <Tabs1>
      <Rectangle69 src={rectangle69} />
      <TabContainer>
        <TabsSelected item={tabsSelectedProps.item} />
        <TabsNormal item={tabsNormal1Props.item} />
        <TabsNormal item={tabsNormal2Props.item} className={tabsNormal2Props.className} />
        <TabsNormal item={tabsNormal3Props.item} className={tabsNormal3Props.className} />
        <TabsNormal item={tabsNormal4Props.item} className={tabsNormal4Props.className} />
      </TabContainer>
    </Tabs1>
  );
}

const Tabs1 = styled.div`
  width: 1130px;
  margin-top: 4px;
  margin-left: 101.67px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  min-height: 48px;
  border: 0px none;
`;

const Rectangle69 = styled.img`
  width: 1130px;
  height: 48px;
  margin-top: -147px;
  align-self: flex-end;
  margin-right: -5px;
`;

const TabContainer = styled.div`
  height: 48px;
  position: relative;
  margin-top: 99px;
  margin-left: 0.83px;
  display: flex;
  align-items: flex-start;
  min-width: 904px;
`;

export default Tabs;
