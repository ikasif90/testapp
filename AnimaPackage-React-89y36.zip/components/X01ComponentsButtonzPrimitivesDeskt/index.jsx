import React from "react";
import X01ComponentsButtonzPrimitivesDeskt2 from "../X01ComponentsButtonzPrimitivesDeskt2";
import styled from "styled-components";


function X01ComponentsButtonzPrimitivesDeskt(props) {
  const { x01ComponentsButtonzPrimitivesDeskt } = props;

  return (
    <Variant>
      <X01ComponentsButtonzPrimitivesDeskt2
        x01ComponentsButtonzPrimitivesLabel={x01ComponentsButtonzPrimitivesDeskt.x01ComponentsButtonzPrimitivesLabel}
      />
    </Variant>
  );
}

const Variant = styled.div`
  height: 46px;
  position: relative;
  display: flex;
  align-items: flex-start;
  min-width: 155px;
  border: 0px none;
`;

export default X01ComponentsButtonzPrimitivesDeskt;
