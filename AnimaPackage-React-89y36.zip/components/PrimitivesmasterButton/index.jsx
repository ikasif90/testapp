import React from "react";
import styled from "styled-components";


function PrimitivesmasterButton(props) {
  const { children } = props;

  return (
    <Primitive>
      <Content>
        <InnerFocus>
          <Label>{children}</Label>
        </InnerFocus>
      </Content>
    </Primitive>
  );
}

const Primitive = styled.div`
  display: flex;
  width: fit-content;
  height: 54px;
  align-items: flex-start;
  border-radius: 4px;
  border: 1px none;
`;

const Content = styled.div`
  display: flex;
  width: fit-content;
  align-items: center;
  padding: 2px;
  align-self: stretch;
  border-radius: 4px;
  border: 1px solid;
  border-color: var(--absolute-zero);
`;

const InnerFocus = styled.div`
  display: flex;
  width: fit-content;
  align-items: center;
  justify-content: center;
  gap: 8px;
  padding: 16px 30px;
  align-self: stretch;
  border-radius: 4px;
  border: 1px none;
`;

const Label = styled.div`
  width: fit-content;
  margin-top: -2px;
  font-family: var(--font-family-helvetica-bold);
  font-weight: 700;
  color: var(--absolute-zero);
  font-size: var(--font-size-m);
  text-align: center;
  letter-spacing: 0;
  line-height: 20px;
  white-space: nowrap;
`;

export default PrimitivesmasterButton;
