import React from "react";
import X01ComponentsLinkzPrimitivesUnderli from "../X01ComponentsLinkzPrimitivesUnderli";
import styled from "styled-components";
import { HelveticaRegularNormalAbsoluteZero1 } from "../../styledMixins";


function X01ComponentsLinkzPrimitivesLabelsD2(props) {
  const { linkText } = props;

  return (
    <Icon>
      <OverlapGroup>
        <X01ComponentsLinkzPrimitivesUnderli />
        <LinkText>{linkText}</LinkText>
      </OverlapGroup>
    </Icon>
  );
}

const Icon = styled.div`
  display: flex;
  align-items: flex-start;
  min-width: 60px;
  border: 0px none;
`;

const OverlapGroup = styled.div`
  width: 59px;
  height: 20px;
  position: relative;
`;

const LinkText = styled.div`
  ${HelveticaRegularNormalAbsoluteZero1}
  position: absolute;
  top: 0;
  left: 0;
  letter-spacing: 0;
  line-height: 20px;
  white-space: nowrap;
`;

export default X01ComponentsLinkzPrimitivesLabelsD2;
