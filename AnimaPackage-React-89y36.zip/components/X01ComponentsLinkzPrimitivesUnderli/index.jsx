import React from "react";
import styled from "styled-components";


function X01ComponentsLinkzPrimitivesUnderli() {
  return <Underline></Underline>;
}

const Underline = styled.div`
  position: absolute;
  width: 58px;
  height: 1px;
  top: 17px;
  left: 1px;
  background-color: #ffffff00;
  border: 0px none;
`;

export default X01ComponentsLinkzPrimitivesUnderli;
