import React from "react";
import V3BetaAccountAccountOutlined from "../V3BetaAccountAccountOutlined";
import styled from "styled-components";


function GlobalNavIconsDONTCHANGEProfile() {
  return (
    <Profile>
      <V3BetaAccountAccountOutlined />
    </Profile>
  );
}

const Profile = styled.div`
  height: 32px;
  position: relative;
  margin-left: 16px;
  display: flex;
  align-items: flex-start;
  min-width: 32px;
  border: 0px none;
`;

export default GlobalNavIconsDONTCHANGEProfile;
