import React from "react";
import PrimitivesmasterIconButton from "../PrimitivesmasterIconButton";
import styled from "styled-components";


function IconButton() {
  return (
    <IconButton1>
      <PrimitivesmasterIconButton />
    </IconButton1>
  );
}

const IconButton1 = styled.div`
  position: relative;
  min-width: 48px;
  height: 48px;
  border: 1px none;
`;

export default IconButton;
