import React from "react";
import styled from "styled-components";


function GlobalNavLogoDONTCHANGELowes() {
  return <LogoLowes></LogoLowes>;
}

const LogoLowes = styled.div`
  position: absolute;
  width: 69px;
  height: 32px;
  top: 5px;
  left: 33px;
  border: 0px none;
  background-image: url(/img/lowe-s-logo@2x.svg);
  background-size: 100% 100%;
`;

export default GlobalNavLogoDONTCHANGELowes;
