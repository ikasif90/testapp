import React from "react";
import GlobalNavLogoDONTCHANGELowes from "../GlobalNavLogoDONTCHANGELowes";
import GlobalNavIconsDONTCHANGESearchInact from "../GlobalNavIconsDONTCHANGESearchInact";
import styled from "styled-components";


function GlobalNavLogoLowesSearchClosed() {
  return (
    <GlobalNavLogoLowesSearchClosed1>
      <OverlapGroup2>
        <Rectangle></Rectangle>
        <GlobalNavLogoDONTCHANGELowes />
      </OverlapGroup2>
      <GlobalNavIconsDONTCHANGESearchInact />
    </GlobalNavLogoLowesSearchClosed1>
  );
}

const GlobalNavLogoLowesSearchClosed1 = styled.div`
  position: absolute;
  height: 40px;
  top: 9px;
  left: 1px;
  display: flex;
  align-items: flex-start;
  min-width: 224px;
  border: 0px none;
`;

const OverlapGroup2 = styled.div`
  width: 102px;
  height: 42px;
  position: relative;
  margin-left: -1px;
  margin-top: -1px;
`;

const Rectangle = styled.div`
  position: absolute;
  width: 34px;
  height: 42px;
  top: 0;
  left: 0;
  border: 0px none;
`;

export default GlobalNavLogoLowesSearchClosed;
