import React from "react";
import DataTablePaginationNumberOfPages from "../DataTablePaginationNumberOfPages";
import DataTablePaginationButtonActive from "../DataTablePaginationButtonActive";
import DataTablePaginationPageNumberInacti from "../DataTablePaginationPageNumberInacti";
import styled from "styled-components";


function DataTablePagination(props) {
  const {
    dataTablePaginationNumberOfPagesPro,
    dataTablePaginationButtonActive1Pro,
    dataTablePaginationButtonActive2Pro,
    dataTablePaginationPageNumberInacti,
    dataTablePaginationPageNumberInacti2,
    dataTablePaginationPageNumberInacti3,
    dataTablePaginationPageNumberInacti4,
    dataTablePaginationPageNumberInacti5,
    dataTablePaginationButtonActive3Pro,
    dataTablePaginationButtonActive4Pro,
  } = props;

  return (
    <DataTablePagination1>
      <DataTablePaginationNumberOfPages>
        {dataTablePaginationNumberOfPagesPro.children}
      </DataTablePaginationNumberOfPages>
      <DataTablePaginationButtonActive>{dataTablePaginationButtonActive1Pro.children}</DataTablePaginationButtonActive>
      <DataTablePaginationButtonActive className={dataTablePaginationButtonActive2Pro.className}>
        {dataTablePaginationButtonActive2Pro.children}
      </DataTablePaginationButtonActive>
      <DataTablePaginationPageNumberInacti>
        {dataTablePaginationPageNumberInacti.children}
      </DataTablePaginationPageNumberInacti>
      <DataTablePaginationPageNumberInacti>
        {dataTablePaginationPageNumberInacti2.children}
      </DataTablePaginationPageNumberInacti>
      <DataTablePaginationPageNumberInacti>
        {dataTablePaginationPageNumberInacti3.children}
      </DataTablePaginationPageNumberInacti>
      <DataTablePaginationPageNumberInacti>
        {dataTablePaginationPageNumberInacti4.children}
      </DataTablePaginationPageNumberInacti>
      <DataTablePaginationPageNumberInacti>
        {dataTablePaginationPageNumberInacti5.children}
      </DataTablePaginationPageNumberInacti>
      <DataTablePaginationButtonActive className={dataTablePaginationButtonActive3Pro.className}>
        {dataTablePaginationButtonActive3Pro.children}
      </DataTablePaginationButtonActive>
      <DataTablePaginationButtonActive className={dataTablePaginationButtonActive4Pro.className}>
        {dataTablePaginationButtonActive4Pro.children}
      </DataTablePaginationButtonActive>
    </DataTablePagination1>
  );
}

const DataTablePagination1 = styled.div`
  position: absolute;
  height: 42px;
  top: 667px;
  left: 761px;
  display: flex;
  align-items: flex-start;
  min-width: 407px;
  border: 0px none;
`;

export default DataTablePagination;
