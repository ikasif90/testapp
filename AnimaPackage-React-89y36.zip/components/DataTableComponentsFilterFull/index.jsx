import React from "react";
import DataTableComponentsFilterIcon from "../DataTableComponentsFilterIcon";
import DataTableComponentsFilterChipStep4 from "../DataTableComponentsFilterChipStep4";
import styled from "styled-components";


function DataTableComponentsFilterFull(props) {
  const { dataTableComponentsFilterChipStep4P } = props;

  return (
    <DataTableFilterIconAndChip>
      <OverlapGroup3>
        <DataTableComponentsFilterIcon />
        <DataTableComponentsFilterChipStep4
          chipTitle={dataTableComponentsFilterChipStep4P.chipTitle}
          filterSearch1={dataTableComponentsFilterChipStep4P.filterSearch1}
        />
        <Rectangle></Rectangle>
        <Rectangle1></Rectangle1>
      </OverlapGroup3>
    </DataTableFilterIconAndChip>
  );
}

const DataTableFilterIconAndChip = styled.div`
  position: absolute;
  height: 44px;
  top: 0;
  left: 0;
  display: flex;
  align-items: flex-start;
  min-width: 249px;
  border: 0px none;
`;

const OverlapGroup3 = styled.div`
  width: 250px;
  height: 46px;
  position: relative;
  margin-left: -1px;
  margin-top: -1px;
`;

const Rectangle = styled.div`
  position: absolute;
  width: 13px;
  height: 46px;
  top: 0;
  left: 0;
  border: 0px none;
`;

const Rectangle1 = styled.div`
  position: absolute;
  width: 146px;
  height: 18px;
  top: 0;
  left: 11px;
  border: 0px none;
`;

export default DataTableComponentsFilterFull;
