import React from "react";
import styled from "styled-components";


function X01ComponentsButtonzPrimitivesLabel(props) {
  const { children } = props;

  return (
    <Icon>
      <ButtonText>{children}</ButtonText>
    </Icon>
  );
}

const Icon = styled.div`
  position: absolute;
  height: 20px;
  top: 13px;
  left: 51px;
  display: flex;
  justify-content: center;
  align-items: flex-start;
  min-width: 53px;
  border: 0px none;
`;

const ButtonText = styled.div`
  min-height: 20px;
  min-width: 90px;
  font-family: var(--font-family-helvetica-bold);
  font-weight: 700;
  color: var(--white);
  font-size: var(--font-size-m);
  text-align: center;
  letter-spacing: 0;
  line-height: 20px;
  white-space: nowrap;
`;

export default X01ComponentsButtonzPrimitivesLabel;
