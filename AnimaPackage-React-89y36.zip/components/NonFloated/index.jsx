import React from "react";
import styled from "styled-components";


function NonFloated() {
  return <Base></Base>;
}

const Base = styled.div`
  position: absolute;
  width: 515px;
  height: 56px;
  top: 0;
  left: 0;
  border-radius: 8px;
  border: 1px solid;
  border-color: #8f8f8f;
`;

export default NonFloated;
