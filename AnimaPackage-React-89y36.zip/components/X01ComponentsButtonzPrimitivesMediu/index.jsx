import React from "react";
import X01ComponentsButtonzPrimitivesDeskt from "../X01ComponentsButtonzPrimitivesDeskt";
import styled from "styled-components";


function X01ComponentsButtonzPrimitivesMediu(props) {
  const { x01ComponentsButtonzPrimitivesDeskt } = props;

  return (
    <DesktopMobile>
      <X01ComponentsButtonzPrimitivesDeskt
        x01ComponentsButtonzPrimitivesDeskt={x01ComponentsButtonzPrimitivesDeskt.x01ComponentsButtonzPrimitivesDeskt}
      />
    </DesktopMobile>
  );
}

const DesktopMobile = styled.div`
  height: 46px;
  position: relative;
  display: flex;
  align-items: flex-start;
  min-width: 155px;
  border: 0px none;
`;

export default X01ComponentsButtonzPrimitivesMediu;
