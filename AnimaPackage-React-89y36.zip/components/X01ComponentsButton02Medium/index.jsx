import React from "react";
import X01ComponentsButtonzPrimitivesMediu from "../X01ComponentsButtonzPrimitivesMediu";
import styled from "styled-components";


function X01ComponentsButton02Medium(props) {
  const { x01ComponentsButtonzPrimitivesMediu } = props;

  return (
    <X01ComponentsButton01Large>
      <X01ComponentsButtonzPrimitivesMediu
        x01ComponentsButtonzPrimitivesDeskt={x01ComponentsButtonzPrimitivesMediu.x01ComponentsButtonzPrimitivesDeskt}
      />
    </X01ComponentsButton01Large>
  );
}

const X01ComponentsButton01Large = styled.div`
  position: absolute;
  height: 49px;
  top: 152px;
  left: 1729px;
  display: flex;
  align-items: flex-start;
  min-width: 155px;
  border: 0px none;
`;

export default X01ComponentsButton02Medium;
