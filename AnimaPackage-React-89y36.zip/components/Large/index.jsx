import React from "react";
import styled from "styled-components";


function Large() {
  return <Large1></Large1>;
}

const Large1 = styled.div`
  display: flex;
  width: fit-content;
  align-items: flex-start;
  position: absolute;
  top: 1px;
  left: 0;
  border: 1px none;
`;

export default Large;
