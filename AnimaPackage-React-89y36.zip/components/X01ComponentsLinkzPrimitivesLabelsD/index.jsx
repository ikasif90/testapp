import React from "react";
import X01ComponentsLinkzPrimitivesLabelsD2 from "../X01ComponentsLinkzPrimitivesLabelsD2";
import styled from "styled-components";


function X01ComponentsLinkzPrimitivesLabelsD(props) {
  const { x01ComponentsLinkzPrimitivesLabelsD } = props;

  return (
    <Color>
      <X01ComponentsLinkzPrimitivesLabelsD2 linkText={x01ComponentsLinkzPrimitivesLabelsD.linkText} />
    </Color>
  );
}

const Color = styled.div`
  height: 20px;
  position: relative;
  display: flex;
  padding: 0 0.5px;
  align-items: flex-start;
  min-width: 61px;
  border: 0px none;
`;

export default X01ComponentsLinkzPrimitivesLabelsD;
