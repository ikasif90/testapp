import React from "react";
import styled from "styled-components";
import { HelveticaBoldBlack16px } from "../../styledMixins";


function TabsSelected(props) {
  const { item } = props;

  return (
    <TabSelected>
      <OverlapGroup>
        <Rectangle></Rectangle>
        <PaperTabCoreSelected>
          <Item>{item}</Item>
        </PaperTabCoreSelected>
        <Line src="/img/line@2x.svg" />
      </OverlapGroup>
    </TabSelected>
  );
}

const TabSelected = styled.div`
  height: 48px;
  display: flex;
  justify-content: center;
  align-items: flex-start;
  min-width: 180px;
  border: 0px none;
`;

const OverlapGroup = styled.div`
  width: 182px;
  height: 52px;
  position: relative;
  margin-top: -1px;
`;

const Rectangle = styled.div`
  position: absolute;
  width: 182px;
  height: 50px;
  top: 0;
  left: 0;
  background-color: #00000000;
  border: 0px none;
`;

const PaperTabCoreSelected = styled.div`
  position: absolute;
  width: 179px;
  height: 19px;
  top: 18px;
  left: 2px;
  display: flex;
  align-items: flex-start;
  border: 0px none;
`;

const Item = styled.div`
  ${HelveticaBoldBlack16px}
  width: 179px;
  min-height: 18px;
  text-align: center;
  letter-spacing: 0;
`;

const Line = styled.img`
  position: absolute;
  width: 175px;
  height: 5px;
  top: 46px;
  left: 4px;
`;

export default TabsSelected;
