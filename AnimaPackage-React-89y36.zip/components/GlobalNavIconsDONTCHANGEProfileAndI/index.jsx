import React from "react";
import GlobalNavIconsDONTCHANGENotificatio from "../GlobalNavIconsDONTCHANGENotificatio";
import GlobalNavIconsDONTCHANGEProfile from "../GlobalNavIconsDONTCHANGEProfile";
import styled from "styled-components";


function GlobalNavIconsDONTCHANGEProfileAndI(props) {
  const { name } = props;

  return (
    <ProfileAndIcons>
      <ProfileAndIcons1>
        <GlobalNavIconsDONTCHANGENotificatio />
        <GlobalNavIconsDONTCHANGEProfile />
        <Name>{name}</Name>
        <OverlapGroup>
          <Rectangle></Rectangle>
          <ExpanderInactive src="/img/expander---inactive@2x.svg" />
        </OverlapGroup>
      </ProfileAndIcons1>
    </ProfileAndIcons>
  );
}

const ProfileAndIcons = styled.div`
  position: absolute;
  height: 32px;
  top: 13px;
  left: 1654px;
  display: flex;
  justify-content: flex-end;
  align-items: flex-start;
  min-width: 267px;
  border: 0px none;
`;

const ProfileAndIcons1 = styled.div`
  width: 265px;
  height: 32px;
  position: relative;
  display: flex;
  align-items: center;
  overflow: hidden;
  border: 0px none;
`;

const Name = styled.div`
  min-height: 12px;
  margin-left: 16px;
  min-width: 72px;
  font-family: var(--font-family-roboto);
  font-weight: 700;
  color: var(--white);
  font-size: var(--font-size-xs);
  letter-spacing: 0;
  line-height: 12px;
  white-space: nowrap;
`;

const OverlapGroup = styled.div`
  width: 42px;
  height: 26px;
  position: relative;
  margin-left: 14px;
`;

const Rectangle = styled.div`
  position: absolute;
  width: 34px;
  height: 26px;
  top: 0;
  left: 8px;
  border: 0px none;
`;

const ExpanderInactive = styled.img`
  position: absolute;
  width: 10px;
  height: 6px;
  top: 10px;
  left: 0;
`;

export default GlobalNavIconsDONTCHANGEProfileAndI;
