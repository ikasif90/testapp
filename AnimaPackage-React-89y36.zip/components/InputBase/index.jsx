import React from "react";
import styled from "styled-components";


function InputBase(props) {
  const { label, input } = props;

  return (
    <InputBase1>
      <InputTextField>
        <Frame804>
          <Label>{label}</Label>
          <Frame803>
            <Input>{input}</Input>
          </Frame803>
        </Frame804>
        <CaretDown src="/img/caret-down@2x.svg" />
      </InputTextField>
      <HelperAndErrorText>
        <Spacer></Spacer>
      </HelperAndErrorText>
    </InputBase1>
  );
}

const InputBase1 = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 8px;
  align-self: stretch;
  border: 1px none;
`;

const InputTextField = styled.div`
  display: flex;
  height: 56.00000762939453px;
  align-items: center;
  gap: 12px;
  padding: 8px 8px 8px 16px;
  align-self: stretch;
  background-color: #ffffff1f;
  border-radius: 4px;
  border: 1px solid;
  border-color: #00000042;
`;

const Frame804 = styled.div`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  flex: 1;
  border: 1px none;
`;

const Label = styled.div`
  width: fit-content;
  margin-top: -1px;
  font-family: var(--font-family-roboto);
  font-weight: 400;
  color: var(--black-2);
  font-size: var(--font-size-xs);
  letter-spacing: 0.18px;
  line-height: 16px;
  white-space: nowrap;
`;

const Frame803 = styled.div`
  display: flex;
  align-items: center;
  align-self: stretch;
  border: 1px none;
`;

const Input = styled.div`
  width: fit-content;
  margin-top: -1px;
  font-family: var(--font-family-roboto);
  font-weight: 400;
  color: var(--black-2);
  font-size: var(--font-size-m);
  letter-spacing: 0.24px;
  line-height: 24px;
  white-space: nowrap;
`;

const CaretDown = styled.img`
  min-width: 24px;
  height: 24px;
`;

const HelperAndErrorText = styled.div`
  display: flex;
  width: fit-content;
  align-items: center;
  border: 1px none;
`;

const Spacer = styled.div`
  min-width: 16px;
  height: 16px;
  border: 1px none;
`;

export default InputBase;
