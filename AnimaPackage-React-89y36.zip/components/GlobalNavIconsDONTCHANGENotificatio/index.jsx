import React from "react";
import styled from "styled-components";


function GlobalNavIconsDONTCHANGENotificatio() {
  return (
    <NotificationFull>
      <Color src="/img/color-1@2x.svg" />
    </NotificationFull>
  );
}

const NotificationFull = styled.div`
  margin-left: 46px;
  display: flex;
  align-items: flex-start;
  min-width: 28px;
  border: 0px none;
`;

const Color = styled.img`
  width: 24px;
  height: 24px;
`;

export default GlobalNavIconsDONTCHANGENotificatio;
