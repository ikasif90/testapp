import React from "react";
import InputBase from "../InputBase";
import styled from "styled-components";


function InputField(props) {
  const { inputBaseProps } = props;

  return (
    <InputField1>
      <InputBase label={inputBaseProps.label} input={inputBaseProps.input} />
    </InputField1>
  );
}

const InputField1 = styled.div`
  display: flex;
  flex-direction: column;
  width: 194px;
  align-items: flex-start;
  position: relative;
  border: 1px none;
`;

export default InputField;
