import React from "react";
import styled from "styled-components";


function ParagraphTextTextScale3(props) {
  const { children } = props;

  return (
    <ParagraphTextTextScale>
      <Body1>{children}</Body1>
    </ParagraphTextTextScale>
  );
}

const ParagraphTextTextScale = styled.div`
  display: flex;
  width: 93px;
  height: 23px;
  align-items: flex-start;
  gap: 10px;
  position: absolute;
  top: 65px;
  left: 131px;
  border: 1px none;
`;

const Body1 = styled.div`
  flex: 1;
  margin-top: -1px;
  font-family: var(--font-family-roboto);
  font-weight: 400;
  color: #012169;
  font-size: var(--font-size-m);
  letter-spacing: 0.24px;
  line-height: 24px;
  white-space: nowrap;
`;

export default ParagraphTextTextScale3;
