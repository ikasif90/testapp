import React from "react";
import styled from "styled-components";


function X100GlobalPrimitivesBasesInteractiv() {
  return <StateButton></StateButton>;
}

const StateButton = styled.div`
  position: absolute;
  width: 155px;
  height: 46px;
  top: 0;
  left: 0;
  background-color: #ffffff00;
  border-radius: 4px;
  border: 0px none;
`;

export default X100GlobalPrimitivesBasesInteractiv;
