import React from "react";
import styled from "styled-components";
import { RobotoNormalAbsoluteZero10px } from "../../styledMixins";


function DataTablePaginationButtonActive(props) {
  const { children, className } = props;

  return (
    <DataTablePaginationButton1 className={`data-table-pagination-button-1 ${className || ""}`}>
      <OverlapGroup3 className="overlap-group3-2">
        <DataTablePaginat className="data-table-paginat">{children}</DataTablePaginat>
        <Rectangle className="rectangle-22"></Rectangle>
      </OverlapGroup3>
    </DataTablePaginationButton1>
  );
}

const DataTablePaginationButton1 = styled.div`
  margin-left: 40px;
  margin-top: 1px;
  display: flex;
  align-items: flex-start;
  min-width: 36px;
  border: 0px none;

  &.data-table-pagination-button-1.data-table-pagination-button-2 {
    margin-left: unset;
  }

  &.data-table-pagination-button-1.data-table-pagination-button-3 {
    margin-left: 16px;
  }

  &.data-table-pagination-button-1.data-table-pagination-button-4 {
    margin-left: unset;
  }
`;

const OverlapGroup3 = styled.div`
  width: 36px;
  height: 19px;
  position: relative;
  border-radius: 4px;
`;

const DataTablePaginat = styled.div`
  ${RobotoNormalAbsoluteZero10px}
  position: absolute;
  top: 4px;
  left: 8px;
  letter-spacing: 0;
`;

const Rectangle = styled.div`
  position: absolute;
  width: 36px;
  height: 19px;
  top: 0;
  left: 0;
  border-radius: 4px;
  border: 0.5px solid;
  border-color: #ffffff00;
`;

export default DataTablePaginationButtonActive;
