import React from "react";
import X01ComponentsLinkzPrimitivesViewpor from "../X01ComponentsLinkzPrimitivesViewpor";
import styled from "styled-components";


function X01ComponentsLinkRegular(props) {
  const { className, x01ComponentsLinkzPrimitivesViewpor } = props;

  return (
    <X01ComponentsLinkRegular1 className={`x01-components-link-regular ${className || ""}`}>
      <X01ComponentsLinkzPrimitivesViewpor
        x01ComponentsLinkzPrimitivesLabelsD={x01ComponentsLinkzPrimitivesViewpor.x01ComponentsLinkzPrimitivesLabelsD}
      />
    </X01ComponentsLinkRegular1>
  );
}

const X01ComponentsLinkRegular1 = styled.div`
  height: 20px;
  position: relative;
  margin-top: 34px;
  display: flex;
  align-items: flex-start;
  min-width: 165px;
  border: 0px none;

  &.x01-components-link-regular.x01-components-link-regular-1 {
    margin-top: 33px;
  }

  &.x01-components-link-regular.x01-components-link-regular-copy {
    margin-top: 33px;
  }

  &.x01-components-link-regular.x01-components-link-regular-copy-2 {
    margin-top: 33px;
  }

  &.x01-components-link-regular.x01-components-link-regular-copy-3 {
    margin-top: 33px;
  }

  &.x01-components-link-regular.x01-components-link-regular-copy-4 {
    margin-top: 33px;
  }

  &.x01-components-link-regular.x01-components-link-regular-copy-5 {
    margin-top: 33px;
  }

  &.x01-components-link-regular.x01-components-link-regular-copy-6 {
    margin-top: 33px;
  }

  &.x01-components-link-regular.x01-components-link-regular-copy-7 {
    margin-top: 33px;
  }

  &.x01-components-link-regular.x01-components-link-regular-copy-8 {
    margin-top: 33px;
  }

  &.x01-components-link-regular.x01-components-link-regular-3 {
    margin-top: 33px;
  }

  &.x01-components-link-regular.x01-components-link-regular-copy-1 {
    margin-top: 33px;
  }

  &.x01-components-link-regular.x01-components-link-regular-copy-2-1 {
    margin-top: 33px;
  }

  &.x01-components-link-regular.x01-components-link-regular-copy-3-1 {
    margin-top: 33px;
  }

  &.x01-components-link-regular.x01-components-link-regular-copy-4-1 {
    margin-top: 33px;
  }

  &.x01-components-link-regular.x01-components-link-regular-copy-5-1 {
    margin-top: 33px;
  }

  &.x01-components-link-regular.x01-components-link-regular-copy-6-1 {
    margin-top: 33px;
  }

  &.x01-components-link-regular.x01-components-link-regular-copy-7-1 {
    margin-top: 33px;
  }

  &.x01-components-link-regular.x01-components-link-regular-copy-8-1 {
    margin-top: 33px;
  }

  &.x01-components-link-regular.x01-components-link-regular-4 {
    margin-top: 33px;
  }

  &.x01-components-link-regular.x01-components-link-regular-copy-9 {
    margin-top: 33px;
  }

  &.x01-components-link-regular.x01-components-link-regular-copy-2-2 {
    margin-top: 33px;
  }

  &.x01-components-link-regular.x01-components-link-regular-copy-3-2 {
    margin-top: 33px;
  }

  &.x01-components-link-regular.x01-components-link-regular-copy-4-2 {
    margin-top: 33px;
  }

  &.x01-components-link-regular.x01-components-link-regular-copy-5-2 {
    margin-top: 33px;
  }

  &.x01-components-link-regular.x01-components-link-regular-copy-6-2 {
    margin-top: 33px;
  }

  &.x01-components-link-regular.x01-components-link-regular-copy-7-2 {
    margin-top: 33px;
  }

  &.x01-components-link-regular.x01-components-link-regular-copy-8-2 {
    margin-top: 33px;
  }
`;

export default X01ComponentsLinkRegular;
