import React from "react";
import styled from "styled-components";


function DataTableComponentsRowBackgroundWhi(props) {
  const { className } = props;

  return (
    <DataTableComponentsRow13BackgroundW className={`data-table-component ${className || ""}`}>
      <Rectangle className="rectangle-7"></Rectangle>
    </DataTableComponentsRow13BackgroundW>
  );
}

const DataTableComponentsRow13BackgroundW = styled.div`
  position: absolute;
  height: 52px;
  top: 645px;
  left: 1px;
  display: flex;
  justify-content: center;
  align-items: flex-start;
  min-width: 1166px;
  border: 0px none;

  &.data-table-component.data-table-component-1 {
    top: 592px;
  }

  &.data-table-component.data-table-component-2 {
    top: 538px;
  }

  &.data-table-component.data-table-component-3 {
    top: 486px;
  }

  &.data-table-component.data-table-component-4 {
    top: 379px;
  }

  &.data-table-component.data-table-component-5 {
    top: 433px;
  }

  &.data-table-component.data-table-component-6 {
    top: 326px;
  }

  &.data-table-component.data-table-component-7 {
    top: 273px;
  }

  &.data-table-component.data-table-component-8 {
    top: 220px;
  }

  &.data-table-component.data-table-component-9 {
    top: 167px;
  }

  &.data-table-component.data-table-component-10 {
    top: 114px;
  }

  &.data-table-component.data-table-component-11 {
    top: 62px;
  }

  &.data-table-component.data-table-component-12 {
    top: 0;
  }
`;

const Rectangle = styled.div`
  width: 1168px;
  height: 54px;
  margin-top: -1px;
  background-color: var(--white);
  border: 0px none;
`;

export default DataTableComponentsRowBackgroundWhi;
