import React from "react";
import styled from "styled-components";


function DataTableComponentsFilterIcon() {
  return (
    <TableFilterIcon>
      <OverlapGroup1>
        <OverlapGroup>
          <RectangleCopy25></RectangleCopy25>
          <RectangleCopy24></RectangleCopy24>
          <Rectangle></Rectangle>
        </OverlapGroup>
        <Rectangle1></Rectangle1>
        <Rectangle2></Rectangle2>
      </OverlapGroup1>
    </TableFilterIcon>
  );
}

const TableFilterIcon = styled.div`
  position: absolute;
  height: 39px;
  top: 4px;
  left: 1px;
  display: flex;
  justify-content: center;
  align-items: flex-start;
  min-width: 27px;
  border: 0px none;
`;

const OverlapGroup1 = styled.div`
  width: 29px;
  height: 41px;
  position: relative;
  margin-top: -1px;
`;

const OverlapGroup = styled.div`
  position: absolute;
  width: 18px;
  top: 15px;
  left: 11px;
  display: flex;
  flex-direction: column;
  padding: 8px 3px;
  align-items: flex-start;
  min-height: 26px;
`;

const RectangleCopy25 = styled.div`
  width: 12px;
  height: 2px;
  background-color: var(--gray);
  border: 1px solid;
  border-color: var(--mountain-mist);
`;

const RectangleCopy24 = styled.div`
  width: 8px;
  height: 2px;
  margin-top: 2px;
  background-color: var(--gray);
  border: 1px solid;
  border-color: var(--mountain-mist);
`;

const Rectangle = styled.div`
  width: 4px;
  height: 2px;
  margin-top: 2px;
  background-color: var(--gray);
  border: 1px solid;
  border-color: var(--mountain-mist);
`;

const Rectangle1 = styled.div`
  position: absolute;
  width: 18px;
  height: 16px;
  top: 0;
  left: 11px;
  border: 0px none;
`;

const Rectangle2 = styled.div`
  position: absolute;
  width: 13px;
  height: 41px;
  top: 0;
  left: 0;
  border: 0px none;
`;

export default DataTableComponentsFilterIcon;
