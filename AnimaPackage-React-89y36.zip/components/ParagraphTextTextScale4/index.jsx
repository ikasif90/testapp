import React from "react";
import styled from "styled-components";


function ParagraphTextTextScale4(props) {
  const { children } = props;

  return (
    <ParagraphTextTextScale>
      <Text>{children}</Text>
    </ParagraphTextTextScale>
  );
}

const ParagraphTextTextScale = styled.div`
  display: flex;
  margin-top: 8px;
  margin-left: 40px;
  width: 868px;
  height: 24px;
  align-items: flex-start;
  gap: 10px;
  border: 1px none;
`;

const Text = styled.p`
  flex: 1;
  margin-top: -1px;
  font-family: var(--font-family-fellix-regular);
  font-weight: 400;
  color: var(--black);
  font-size: var(--font-size-m);
  letter-spacing: 0.24px;
  line-height: 24px;
  white-space: nowrap;
`;

export default ParagraphTextTextScale4;
