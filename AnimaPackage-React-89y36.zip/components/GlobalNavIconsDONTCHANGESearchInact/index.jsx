import React from "react";
import styled from "styled-components";


function GlobalNavIconsDONTCHANGESearchInact() {
  return (
    <SearchInactive>
      <Rectangle></Rectangle>
      <V2search src="/img/v2-search@2x.svg" />
    </SearchInactive>
  );
}

const SearchInactive = styled.div`
  height: 24px;
  align-self: center;
  margin-left: 79px;
  display: flex;
  align-items: flex-start;
  min-width: 26px;
  border: 0px none;
`;

const Rectangle = styled.div`
  width: 4px;
  height: 26px;
  margin-left: -1px;
  margin-top: -1px;
  background-color: var(--white);
  border: 0px none;
`;

const V2search = styled.img`
  width: 16px;
  height: 16px;
  align-self: center;
  margin-left: 7px;
`;

export default GlobalNavIconsDONTCHANGESearchInact;
