import React from "react";
import styled from "styled-components";


function PrimitivesmasterIconButton() {
  return (
    <Primitive>
      <Content>
        <Icon src="/img/icon@2x.svg" />
      </Content>
    </Primitive>
  );
}

const Primitive = styled.div`
  display: flex;
  width: 48px;
  height: 48px;
  align-items: flex-start;
  gap: 10px;
  border: 1px none;
`;

const Content = styled.div`
  position: relative;
  min-width: 48px;
  height: 48px;
  border-radius: 8px;
`;

const Icon = styled.img`
  position: absolute;
  width: 20px;
  height: 20px;
  top: 14px;
  left: 14px;
`;

export default PrimitivesmasterIconButton;
