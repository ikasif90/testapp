import React from "react";
import styled from "styled-components";
import { HelveticaBoldBlack16px } from "../../styledMixins";


function TabsNormal(props) {
  const { item, className } = props;

  return (
    <TabNormal className={`tab-normal ${className || ""}`}>
      <OverlapGroup1 className="overlap-group1-2">
        <Item className="item-1">{item}</Item>
      </OverlapGroup1>
    </TabNormal>
  );
}

const TabNormal = styled.div`
  margin-left: 15px;
  display: flex;
  justify-content: flex-end;
  align-items: flex-start;
  min-width: 160px;
  border: 0px none;

  &.tab-normal.tab-normal-1 {
    margin-left: 10px;
  }

  &.tab-normal.tab-normal-2 {
    margin-left: 49px;
  }

  &.tab-normal.tab-normal-3 {
    margin-left: 10px;
  }
`;

const OverlapGroup1 = styled.div`
  height: 48px;
  display: flex;
  padding: 13px 0px;
  align-items: flex-end;
  min-width: 178px;
  background-image: url(/img/paper-tab@2x.png);
  background-size: 100% 100%;
`;

const Item = styled.div`
  ${HelveticaBoldBlack16px}
  width: 159px;
  min-height: 18px;
  text-align: center;
  letter-spacing: 0;
`;

const OverlapGroup3 = styled.div`
  .tab-normal.tab-normal-2 & {
    padding: 13px 0;
  }
`;

const OverlapGroup4 = styled.div`
  .tab-normal.tab-normal-3 & {
    padding: 13px 0;
  }
`;

export default TabsNormal;
