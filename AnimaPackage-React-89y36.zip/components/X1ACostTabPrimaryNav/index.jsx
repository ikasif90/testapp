import React from "react";
import ParagraphTextTextScale from "../ParagraphTextTextScale";
import GlobalNavMenuOptions2InactiveExpand from "../GlobalNavMenuOptions2InactiveExpand";
import ParagraphTextTextScale2 from "../ParagraphTextTextScale2";
import GlobalNavIconsDONTCHANGEProfileAndI from "../GlobalNavIconsDONTCHANGEProfileAndI";
import GlobalNavLogoLowesSearchClosed from "../GlobalNavLogoLowesSearchClosed";
import ParagraphTextTextScale3 from "../ParagraphTextTextScale3";
import X01ComponentsButton02Medium from "../X01ComponentsButton02Medium";
import Tabs from "../Tabs";
import ParagraphTextTextScale4 from "../ParagraphTextTextScale4";
import StandardSearch from "../StandardSearch";
import InputField from "../InputField";
import Large from "../Large";
import Large2 from "../Large2";
import X01ComponentsScrollbarzPrimitivesAc from "../X01ComponentsScrollbarzPrimitivesAc";
import DataTableComponentsRowBackgroundWhi from "../DataTableComponentsRowBackgroundWhi";
import Group8 from "../Group8";
import X01ComponentsLinkRegular from "../X01ComponentsLinkRegular";
import DataTableComponentsPaginationRowsPe from "../DataTableComponentsPaginationRowsPe";
import DataTableComponentsFilterFull from "../DataTableComponentsFilterFull";
import DataTablePagination from "../DataTablePagination";
import styled from "styled-components";
import {
  RobotoBoldDoveGray14px,
  RobotoBoldHunterGreen16px,
  RobotoBoldBlack16px,
  RobotoNormalBlack16px,
  RobotoMediumHunterGreen28px,
} from "../../styledMixins";
import "./X1ACostTabPrimaryNav.css";

function X1ACostTabPrimaryNav(props) {
  const {
    homeOfficeVbu,
    phone,
    programType,
    dropShip,
    welcome,
    title,
    helperText,
    applications,
    costChangeRequests1,
    costChangeRequests2,
    requestName,
    request,
    x0123445671,
    x133450561,
    x234245761,
    x234345701,
    x123499501,
    x0123445672,
    x133450562,
    x234245762,
    x234345702,
    x123499502,
    dateSubmitted,
    date1,
    date2,
    date3,
    date4,
    date5,
    date6,
    date7,
    date8,
    date9,
    date10,
    v2ArrowDown4,
    itemType,
    sosOnline1,
    sosOnline2,
    stock1,
    stock2,
    stock3,
    sosOnline3,
    sosOnline4,
    stock4,
    sosOnline5,
    sosOnline6,
    locationType,
    onlineOnly1,
    stock5,
    stock6,
    onlineOnly2,
    stock7,
    stock8,
    onlineOnly3,
    onlineOnly4,
    stock9,
    stock10,
    draft1,
    draft2,
    draft3,
    draft4,
    submitted1,
    submitted2,
    submitted3,
    submitted4,
    submitted5,
    submitted6,
    status,
    paragraphTextTextScale1Props,
    paragraphTextTextScale2Props,
    paragraphTextTextScale3Props,
    paragraphTextTextScale4Props,
    globalNavIconsDONTCHANGEProfileAndI,
    paragraphTextTextScale3Props2,
    paragraphTextTextScale5Props,
    x01ComponentsButton02MediumProps,
    tabsProps,
    paragraphTextTextScale4Props2,
    standardSearchProps,
    inputFieldProps,
    large2Props,
    dataTableComponentsRowBackgroundWhi,
    dataTableComponentsRowBackgroundWhi2,
    dataTableComponentsRowBackgroundWhi3,
    dataTableComponentsRowBackgroundWhi4,
    dataTableComponentsRowBackgroundWhi5,
    dataTableComponentsRowBackgroundWhi6,
    dataTableComponentsRowBackgroundWhi7,
    dataTableComponentsRowBackgroundWhi8,
    dataTableComponentsRowBackgroundWhi9,
    dataTableComponentsRowBackgroundWhi10,
    dataTableComponentsRowBackgroundWhi11,
    group81Props,
    group82Props,
    x01ComponentsLinkRegular1Props,
    x01ComponentsLinkRegular2Props,
    x01ComponentsLinkRegular3Props,
    x01ComponentsLinkRegular4Props,
    x01ComponentsLinkRegular5Props,
    x01ComponentsLinkRegular6Props,
    x01ComponentsLinkRegular7Props,
    x01ComponentsLinkRegular8Props,
    x01ComponentsLinkRegular9Props,
    x01ComponentsLinkRegular10Props,
    dataTableComponentsRowBackgroundWhi12,
    dataTableComponentsPaginationRowsPe,
    dataTableComponentsFilterFullProps,
    dataTablePaginationProps,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="x1a-cost-tab-primary-nav screen">
        <OverlapGroup9>
          <OverlapGroup7>
            <GlobalNavMainNavVendorLowes>
              <OverlapGroup3>
                <OverlapGroup>
                  <Rectangle></Rectangle>
                  <NavigationBackground></NavigationBackground>
                  <Rectangle1></Rectangle1>
                </OverlapGroup>
                <MenuMain>
                  <Rectangle2></Rectangle2>
                  <ParagraphTextTextScale>{paragraphTextTextScale1Props.children}</ParagraphTextTextScale>
                  <OverlapGroup1>
                    <GlobalNavMenuOptions2InactiveExpand />
                  </OverlapGroup1>
                  <ParagraphTextTextScale className={paragraphTextTextScale2Props.className}>
                    {paragraphTextTextScale2Props.children}
                  </ParagraphTextTextScale>
                  <ParagraphTextTextScale className={paragraphTextTextScale3Props.className}>
                    {paragraphTextTextScale3Props.children}
                  </ParagraphTextTextScale>
                  <ParagraphTextTextScale className={paragraphTextTextScale4Props.className}>
                    {paragraphTextTextScale4Props.children}
                  </ParagraphTextTextScale>
                  <ParagraphTextTextScale2 />
                </MenuMain>
                <GlobalNavIconsDONTCHANGEProfileAndI name={globalNavIconsDONTCHANGEProfileAndI.name} />
                <GlobalNavLogoLowesSearchClosed />
                <ParagraphTextTextScale3>{paragraphTextTextScale3Props2.children}</ParagraphTextTextScale3>
              </OverlapGroup3>
            </GlobalNavMainNavVendorLowes>
            <ParagraphTextTextScale className={paragraphTextTextScale5Props.className}>
              {paragraphTextTextScale5Props.children}
            </ParagraphTextTextScale>
          </OverlapGroup7>
          <X01ComponentsButton02Medium
            x01ComponentsButtonzPrimitivesMediu={x01ComponentsButton02MediumProps.x01ComponentsButtonzPrimitivesMediu}
          />
          <Group10>
            <HomeOfficeVBU>{homeOfficeVbu}</HomeOfficeVBU>
            <Phone>{phone}</Phone>
          </Group10>
          <Group10Copy>
            <PROGRAMTYPE>{programType}</PROGRAMTYPE>
            <DropShip>{dropShip}</DropShip>
          </Group10Copy>
          <Group13>
            <Welcome>{welcome}</Welcome>
            <Title>{title}</Title>
          </Group13>
        </OverlapGroup9>
        <HelperText>{helperText}</HelperText>
        <OverlapGroup6>
          <Group14>
            <Applications>{applications}</Applications>
          </Group14>
          <Tabs
            rectangle69={tabsProps.rectangle69}
            tabsSelectedProps={tabsProps.tabsSelectedProps}
            tabsNormal1Props={tabsProps.tabsNormal1Props}
            tabsNormal2Props={tabsProps.tabsNormal2Props}
            tabsNormal3Props={tabsProps.tabsNormal3Props}
            tabsNormal4Props={tabsProps.tabsNormal4Props}
          />
          <OverlapGroup8>
            <Group15>
              <OverlapGroup11>
                <CostChangeRequests>{costChangeRequests1}</CostChangeRequests>
                <ParagraphTextTextScale4>{paragraphTextTextScale4Props2.children}</ParagraphTextTextScale4>
                <FlexRow>
                  <FlexCol>
                    <StandardSearch
                      primitivesMasterSearchLargeProps={standardSearchProps.primitivesMasterSearchLargeProps}
                    />
                    <CostChangeRequests1>{costChangeRequests2}</CostChangeRequests1>
                  </FlexCol>
                  <DateSelector>
                    <InputField inputBaseProps={inputFieldProps.inputBaseProps} />
                  </DateSelector>
                  <LargeContainer>
                    <Large />
                    <Large2 primitivesmasterButtonProps={large2Props.primitivesmasterButtonProps} />
                  </LargeContainer>
                </FlexRow>
              </OverlapGroup11>
            </Group15>
            <StateScrollbar>
              <X01ComponentsScrollbarzPrimitivesAc />
            </StateScrollbar>
            <DataTableFullTableWithFilterAndPagi>
              <OverlapGroup5>
                <DataTableComponentsRowBackgroundWhi />
                <DataTableComponentsRowBackgroundWhi className={dataTableComponentsRowBackgroundWhi.className} />
                <DataTableComponentsRowBackgroundWhi className={dataTableComponentsRowBackgroundWhi2.className} />
                <DataTableComponentsRowBackgroundWhi className={dataTableComponentsRowBackgroundWhi3.className} />
                <DataTableComponentsRowBackgroundWhi className={dataTableComponentsRowBackgroundWhi4.className} />
                <DataTableComponentsRowBackgroundWhi className={dataTableComponentsRowBackgroundWhi5.className} />
                <DataTableComponentsRowBackgroundWhi className={dataTableComponentsRowBackgroundWhi6.className} />
                <DataTableComponentsRowBackgroundWhi className={dataTableComponentsRowBackgroundWhi7.className} />
                <DataTableComponentsRowBackgroundWhi className={dataTableComponentsRowBackgroundWhi8.className} />
                <DataTableComponentsRowBackgroundWhi className={dataTableComponentsRowBackgroundWhi9.className} />
                <DataTableComponentsRowBackgroundWhi className={dataTableComponentsRowBackgroundWhi10.className} />
                <DataTableComponentsRowBackgroundWhi className={dataTableComponentsRowBackgroundWhi11.className} />
                <Group8 {...group81Props} />
                <Group8 {...group82Props} />
                <Group101>
                  <Group5>
                    <OverlapGroup2>
                      <RequestName>{requestName}</RequestName>
                      <V2arrowDown src="/img/v2-arrow-down-2@2x.svg" />
                    </OverlapGroup2>
                  </Group5>
                  <X01ComponentsLinkRegular
                    x01ComponentsLinkzPrimitivesViewpor={
                      x01ComponentsLinkRegular1Props.x01ComponentsLinkzPrimitivesViewpor
                    }
                  />
                  <X01ComponentsLinkRegular
                    className={x01ComponentsLinkRegular2Props.className}
                    x01ComponentsLinkzPrimitivesViewpor={
                      x01ComponentsLinkRegular2Props.x01ComponentsLinkzPrimitivesViewpor
                    }
                  />
                  <X01ComponentsLinkRegular
                    className={x01ComponentsLinkRegular3Props.className}
                    x01ComponentsLinkzPrimitivesViewpor={
                      x01ComponentsLinkRegular3Props.x01ComponentsLinkzPrimitivesViewpor
                    }
                  />
                  <X01ComponentsLinkRegular
                    className={x01ComponentsLinkRegular4Props.className}
                    x01ComponentsLinkzPrimitivesViewpor={
                      x01ComponentsLinkRegular4Props.x01ComponentsLinkzPrimitivesViewpor
                    }
                  />
                  <X01ComponentsLinkRegular
                    className={x01ComponentsLinkRegular5Props.className}
                    x01ComponentsLinkzPrimitivesViewpor={
                      x01ComponentsLinkRegular5Props.x01ComponentsLinkzPrimitivesViewpor
                    }
                  />
                  <X01ComponentsLinkRegular
                    className={x01ComponentsLinkRegular6Props.className}
                    x01ComponentsLinkzPrimitivesViewpor={
                      x01ComponentsLinkRegular6Props.x01ComponentsLinkzPrimitivesViewpor
                    }
                  />
                  <X01ComponentsLinkRegular
                    className={x01ComponentsLinkRegular7Props.className}
                    x01ComponentsLinkzPrimitivesViewpor={
                      x01ComponentsLinkRegular7Props.x01ComponentsLinkzPrimitivesViewpor
                    }
                  />
                  <X01ComponentsLinkRegular
                    className={x01ComponentsLinkRegular8Props.className}
                    x01ComponentsLinkzPrimitivesViewpor={
                      x01ComponentsLinkRegular8Props.x01ComponentsLinkzPrimitivesViewpor
                    }
                  />
                  <X01ComponentsLinkRegular
                    className={x01ComponentsLinkRegular9Props.className}
                    x01ComponentsLinkzPrimitivesViewpor={
                      x01ComponentsLinkRegular9Props.x01ComponentsLinkzPrimitivesViewpor
                    }
                  />
                  <X01ComponentsLinkRegular
                    className={x01ComponentsLinkRegular10Props.className}
                    x01ComponentsLinkzPrimitivesViewpor={
                      x01ComponentsLinkRegular10Props.x01ComponentsLinkzPrimitivesViewpor
                    }
                  />
                </Group101>
                <Group81>
                  <Group51>
                    <OverlapGroup4>
                      <Request>{request}</Request>
                      <V2arrowDown1 src="/img/v2-arrow-down-3@2x.svg" />
                    </OverlapGroup4>
                  </Group51>
                  <X012344567>{x0123445671}</X012344567>
                  <X13345056>{x133450561}</X13345056>
                  <X13345056>{x234245761}</X13345056>
                  <X13345056>{x234345701}</X13345056>
                  <X13345056>{x123499501}</X13345056>
                  <X13345056>{x0123445672}</X13345056>
                  <X13345056>{x133450562}</X13345056>
                  <X13345056>{x234245762}</X13345056>
                  <X13345056>{x234345702}</X13345056>
                  <X13345056>{x123499502}</X13345056>
                </Group81>
                <Group82>
                  <Group52>
                    <DateSubmitted>{dateSubmitted}</DateSubmitted>
                    <V2arrowDown2 src="/img/v2-arrow-down-4@2x.svg" />
                  </Group52>
                  <Date>{date1}</Date>
                  <Date1>{date2}</Date1>
                  <Date1>{date3}</Date1>
                  <Date1>{date4}</Date1>
                  <Date1>{date5}</Date1>
                  <Date1>{date6}</Date1>
                  <Date1>{date7}</Date1>
                  <Date1>{date8}</Date1>
                  <Date1>{date9}</Date1>
                  <Date1>{date10}</Date1>
                </Group82>
                <Group83>
                  <Group53>
                    <V2arrowDown3 src={v2ArrowDown4} />
                    <OverlapGroup10>
                      <ItemType>{itemType}</ItemType>
                      <V2arrowDown4 src="/img/v2-arrow-down-6@2x.svg" />
                    </OverlapGroup10>
                  </Group53>
                  <X012344567>{sosOnline1}</X012344567>
                  <X13345056>{sosOnline2}</X13345056>
                  <X13345056>{stock1}</X13345056>
                  <X13345056>{stock2}</X13345056>
                  <X13345056>{stock3}</X13345056>
                  <X13345056>{sosOnline3}</X13345056>
                  <X13345056>{sosOnline4}</X13345056>
                  <X13345056>{stock4}</X13345056>
                  <X13345056>{sosOnline5}</X13345056>
                  <X13345056>{sosOnline6}</X13345056>
                </Group83>
                <Group84>
                  <Group54>
                    <LocationType>{locationType}</LocationType>
                    <V2arrowDown5 src="/img/v2-arrow-down-7@2x.svg" />
                  </Group54>
                  <Date>{onlineOnly1}</Date>
                  <Date1>{stock5}</Date1>
                  <Date1>{stock6}</Date1>
                  <Date1>{onlineOnly2}</Date1>
                  <Date1>{stock7}</Date1>
                  <Date1>{stock8}</Date1>
                  <Date1>{onlineOnly3}</Date1>
                  <Date1>{onlineOnly4}</Date1>
                  <Date1>{stock9}</Date1>
                  <Date1>{stock10}</Date1>
                </Group84>
                <Group85>
                  <Draft>{draft1}</Draft>
                  <X13345056>{draft2}</X13345056>
                  <X13345056>{draft3}</X13345056>
                  <X13345056>{draft4}</X13345056>
                  <X13345056>{submitted1}</X13345056>
                  <X13345056>{submitted2}</X13345056>
                  <X13345056>{submitted3}</X13345056>
                  <X13345056>{submitted4}</X13345056>
                  <X13345056>{submitted5}</X13345056>
                  <X13345056>{submitted6}</X13345056>
                </Group85>
                <Group55>
                  <V2arrowDown6 src="/img/v2-arrow-down-8@2x.svg" />
                </Group55>
                <Status>{status}</Status>
                <DataTableComponentsRowBackgroundWhi className={dataTableComponentsRowBackgroundWhi12.className} />
                <V2close src="/img/v2-close@2x.svg" />
                <Lines src="/img/lines@1x.svg" />
                <DataTableComponentsPaginationRowsPe number={dataTableComponentsPaginationRowsPe.number} />
                <DataTableComponentsFilterFull
                  dataTableComponentsFilterChipStep4P={
                    dataTableComponentsFilterFullProps.dataTableComponentsFilterChipStep4P
                  }
                />
                <DataTablePagination {...dataTablePaginationProps} />
              </OverlapGroup5>
            </DataTableFullTableWithFilterAndPagi>
          </OverlapGroup8>
        </OverlapGroup6>
      </div>
    </div>
  );
}

const OverlapGroup9 = styled.div`
  width: 1920px;
  height: 208px;
  position: relative;
`;

const OverlapGroup7 = styled.div`
  position: absolute;
  width: 1920px;
  height: 159px;
  top: 0;
  left: 0;
`;

const GlobalNavMainNavVendorLowes = styled.div`
  position: absolute;
  height: 128px;
  top: 0;
  left: 0;
  display: flex;
  justify-content: center;
  align-items: flex-start;
  min-width: 1920px;
  border: 1px none;
`;

const OverlapGroup3 = styled.div`
  width: 1922px;
  height: 130px;
  position: relative;
  margin-top: -1px;
`;

const OverlapGroup = styled.div`
  position: absolute;
  width: 1922px;
  height: 130px;
  top: 0;
  left: 0;
`;

const Rectangle = styled.div`
  position: absolute;
  width: 1922px;
  height: 34px;
  top: 96px;
  left: 0;
  background-color: var(--white);
  border: 0px none;
  box-shadow: 0px 1px 6px #00000033;
`;

const NavigationBackground = styled.div`
  position: absolute;
  width: 1922px;
  height: 42px;
  top: 56px;
  left: 0;
  background-color: #011e5f;
  border: 0px none;
`;

const Rectangle1 = styled.div`
  position: absolute;
  width: 1922px;
  height: 58px;
  top: 0;
  left: 0;
  background-color: #01174a;
  border: 0px none;
`;

const MenuMain = styled.div`
  position: absolute;
  height: 38px;
  top: 59px;
  left: 1px;
  display: flex;
  align-items: center;
  min-width: 864px;
  border: 0px none;
`;

const Rectangle2 = styled.div`
  width: 34px;
  height: 40px;
  margin-left: -1px;
  align-self: flex-start;
  margin-top: -1px;
  border: 0px none;
`;

const OverlapGroup1 = styled.div`
  height: 42px;
  position: relative;
  align-self: flex-start;
  margin-left: 14px;
  margin-top: -3.5px;
  display: flex;
  padding: 0 0.5px;
  align-items: flex-end;
  min-width: 126px;
  background-image: url(/img/path@2x.svg);
  background-size: 100% 100%;
`;

const Group10 = styled.div`
  position: absolute;
  width: 129px;
  height: 48px;
  top: 152px;
  left: 1553px;
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  border: 0px none;
`;

const HomeOfficeVBU = styled.div`
  ${RobotoBoldDoveGray14px}
  min-height: 24px;
  min-width: 128px;
  text-align: right;
  letter-spacing: 0.56px;
  line-height: 24px;
  white-space: nowrap;
`;

const Phone = styled.div`
  ${RobotoBoldHunterGreen16px}
  min-height: 20px;
  margin-top: 4px;
  min-width: 56px;
  text-align: right;
  letter-spacing: 0;
  line-height: 20px;
  white-space: nowrap;
`;

const Group10Copy = styled.div`
  position: absolute;
  width: 112px;
  height: 48px;
  top: 152px;
  left: 1401px;
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  border: 0px none;
`;

const PROGRAMTYPE = styled.div`
  ${RobotoBoldDoveGray14px}
  min-height: 24px;
  min-width: 112px;
  text-align: right;
  letter-spacing: 0.56px;
  line-height: 24px;
  white-space: nowrap;
`;

const DropShip = styled.div`
  ${RobotoBoldHunterGreen16px}
  width: 73px;
  min-height: 20px;
  margin-top: 4px;
  text-align: right;
  letter-spacing: 0;
  line-height: 20px;
  white-space: nowrap;
`;

const Group13 = styled.div`
  position: absolute;
  width: 360px;
  height: 64px;
  top: 144px;
  left: 136px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  border: 0px none;
`;

const Welcome = styled.div`
  min-height: 20px;
  font-family: var(--font-family-roboto);
  font-weight: 400;
  color: var(--eerie-black);
  font-size: var(--font-size-m);
  letter-spacing: 0;
  line-height: 20px;
  white-space: nowrap;
`;

const Title = styled.h1`
  min-height: 44px;
  font-family: var(--font-family-roboto);
  font-weight: 700;
  color: var(--eerie-black);
  font-size: var(--font-size-xxl);
  letter-spacing: 0;
  line-height: 44px;
  white-space: nowrap;
`;

const HelperText = styled.div`
  min-height: 16px;
  margin-top: 8px;
  margin-left: 513px;
  min-width: 1px;
  font-family: var(--font-family-roboto);
  font-weight: 400;
  color: #0000008a;
  font-size: var(--font-size-xs);
  letter-spacing: 0;
  line-height: 16px;
  white-space: nowrap;
`;

const OverlapGroup6 = styled.div`
  width: 1920px;
  position: relative;
  margin-top: 10px;
  display: flex;
  flex-direction: column;
  padding: 23px 21.3px;
  align-items: flex-start;
  min-height: 1153px;
  background-image: url(/img/rectangle@1x.svg);
  background-size: 100% 100%;
`;

const Group14 = styled.div`
  width: 342px;
  height: 32px;
  margin-top: 15px;
  margin-left: 114.67px;
  display: flex;
  align-items: flex-start;
  border: 0px none;
`;

const Applications = styled.div`
  min-height: 32px;
  font-family: var(--font-family-roboto);
  font-weight: 700;
  color: #6d7278;
  font-size: var(--font-size-l);
  letter-spacing: 0;
  line-height: 32px;
  white-space: nowrap;
`;

const OverlapGroup8 = styled.div`
  width: 1741px;
  height: 1005px;
  position: relative;
  margin-top: 3px;
`;

const Group15 = styled.div`
  position: absolute;
  width: 1381px;
  height: 1005px;
  top: 0;
  left: 0;
  display: flex;
  align-items: flex-end;
  overflow: hidden;
  border: 0px none;
`;

const OverlapGroup11 = styled.div`
  width: 1879px;
  position: relative;
  margin-left: -1px;
  margin-bottom: -331.66px;
  display: flex;
  flex-direction: column;
  padding: 23.7px 121px;
  align-items: flex-start;
  min-height: 1337px;
  background-color: var(--white);
  border-radius: 8px;
`;

const CostChangeRequests = styled.div`
  ${RobotoMediumHunterGreen28px}
  min-height: 30px;
  margin-left: 40px;
  letter-spacing: 0;
  line-height: 30px;
  white-space: nowrap;
`;

const FlexRow = styled.div`
  height: 240px;
  margin-top: 50px;
  display: flex;
  align-items: flex-start;
  min-width: 1286px;
`;

const FlexCol = styled.div`
  width: 515px;
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  min-height: 240px;
`;

const CostChangeRequests1 = styled.div`
  ${RobotoMediumHunterGreen28px}
  width: 380px;
  min-height: 30px;
  margin-top: 154px;
  margin-right: 55px;
  letter-spacing: 0;
  line-height: 30px;
  white-space: nowrap;
`;

const DateSelector = styled.div`
  display: flex;
  position: relative;
  margin-left: 20px;
  width: fit-content;
  align-items: flex-start;
  justify-content: flex-end;
  gap: 16px;
  padding: 0px 36px 0px 0px;
  border: 1px none;
`;

const LargeContainer = styled.div`
  width: 369px;
  height: 55px;
  position: relative;
  margin-left: 152px;
`;

const StateScrollbar = styled.div`
  position: absolute;
  width: 805px;
  height: 489px;
  top: 64px;
  left: 1252px;
  display: flex;
  padding: 0 54px;
  align-items: flex-start;
  border: 0px none;
  transform: rotate(90deg);
`;

const DataTableFullTableWithFilterAndPagi = styled.div`
  position: absolute;
  width: 1168px;
  height: 709px;
  top: 216px;
  left: 115px;
  display: flex;
  align-items: flex-start;
  overflow: hidden;
  border: 0px none;
`;

const OverlapGroup5 = styled.div`
  width: 1168px;
  height: 709px;
  position: relative;
  margin-top: 0;
`;

const Group101 = styled.div`
  position: absolute;
  width: 165px;
  top: 76px;
  left: 659px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  min-height: 551px;
`;

const Group5 = styled.div`
  width: 131px;
  display: flex;
  align-items: flex-start;
  border: 0px none;
`;

const OverlapGroup2 = styled.div`
  width: 131px;
  height: 20px;
  position: relative;
`;

const RequestName = styled.div`
  ${RobotoBoldBlack16px}
  position: absolute;
  top: 0;
  left: 0;
  letter-spacing: 0;
  line-height: 20px;
  white-space: nowrap;
`;

const V2arrowDown = styled.img`
  position: absolute;
  width: 20px;
  height: 20px;
  top: 0;
  left: 111px;
`;

const Group81 = styled.div`
  ${RobotoNormalBlack16px}
  position: absolute;
  width: 151px;
  height: 551px;
  top: 77px;
  left: 209px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  border: 0px none;
`;

const Group51 = styled.div`
  width: 151px;
  display: flex;
  align-items: flex-start;
  overflow: hidden;
  border: 0px none;
`;

const OverlapGroup4 = styled.div`
  width: 185px;
  height: 20px;
  position: relative;
`;

const Request = styled.div`
  ${RobotoBoldBlack16px}
  position: absolute;
  width: 185px;
  top: 0;
  left: 0;
  letter-spacing: 0;
  line-height: 20px;
  white-space: nowrap;
`;

const V2arrowDown1 = styled.img`
  position: absolute;
  width: 20px;
  height: 20px;
  top: 0;
  left: 92px;
`;

const X012344567 = styled.div`
  min-height: 20px;
  margin-top: 34px;
  letter-spacing: 0;
  line-height: 20px;
  white-space: nowrap;
`;

const Date = styled.div`
  ${RobotoNormalBlack16px}
  min-height: 20px;
  margin-top: 34px;
  letter-spacing: 0;
  line-height: 20px;
  white-space: nowrap;
`;

const X13345056 = styled.div`
  min-height: 20px;
  margin-top: 33px;
  letter-spacing: 0;
  line-height: 20px;
  white-space: nowrap;
`;

const Date1 = styled.div`
  ${RobotoNormalBlack16px}
  min-height: 20px;
  margin-top: 33px;
  letter-spacing: 0;
  line-height: 20px;
  white-space: nowrap;
`;

const Group82 = styled.div`
  position: absolute;
  width: 137px;
  height: 551px;
  top: 77px;
  left: 349px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  border: 0px none;
`;

const Group52 = styled.div`
  width: 137px;
  display: flex;
  align-items: flex-start;
  border: 0px none;
`;

const DateSubmitted = styled.div`
  ${RobotoBoldBlack16px}
  min-height: 20px;
  min-width: 82px;
  letter-spacing: 0;
  line-height: 20px;
  white-space: nowrap;
`;

const V2arrowDown2 = styled.img`
  width: 20px;
  height: 20px;
`;

const Group83 = styled.div`
  ${RobotoNormalBlack16px}
  position: absolute;
  width: 162px;
  height: 551px;
  top: 76px;
  left: 491px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  overflow: hidden;
  border: 0px none;
`;

const Group53 = styled.div`
  width: 250px;
  display: flex;
  align-items: flex-start;
  overflow: hidden;
  border: 0px none;
`;

const V2arrowDown3 = styled.img`
  width: 51px;
  height: 20px;
  margin-left: -300px;
  margin-top: -490px;
`;

const OverlapGroup10 = styled.div`
  width: 288px;
  height: 20px;
  position: relative;
  margin-left: 249px;
`;

const ItemType = styled.div`
  ${RobotoBoldBlack16px}
  position: absolute;
  width: 288px;
  top: 0;
  left: 0;
  letter-spacing: 0;
  line-height: 20px;
  white-space: nowrap;
`;

const V2arrowDown4 = styled.img`
  position: absolute;
  width: 20px;
  height: 20px;
  top: 0;
  left: 117px;
`;

const Group84 = styled.div`
  position: absolute;
  width: 127px;
  height: 551px;
  top: 76px;
  left: 854px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  border: 0px none;
`;

const Group54 = styled.div`
  width: 127px;
  display: flex;
  align-items: flex-start;
  border: 0px none;
`;

const LocationType = styled.div`
  ${RobotoBoldBlack16px}
  min-height: 20px;
  min-width: 99px;
  letter-spacing: 0;
  line-height: 20px;
  white-space: nowrap;
`;

const V2arrowDown5 = styled.img`
  width: 20px;
  height: 20px;
  margin-left: 8px;
`;

const Group85 = styled.div`
  ${RobotoNormalBlack16px}
  position: absolute;
  width: 74px;
  height: 551px;
  top: 76px;
  left: 1062px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  border: 0px none;
`;

const Draft = styled.div`
  min-height: 20px;
  margin-top: 54px;
  letter-spacing: 0;
  line-height: 20px;
  white-space: nowrap;
`;

const Group55 = styled.div`
  position: absolute;
  width: 72px;
  height: 20px;
  top: 76px;
  left: 1088px;
  display: flex;
  align-items: flex-start;
  border: 0px none;
`;

const V2arrowDown6 = styled.img`
  width: 20px;
  height: 20px;
  margin-left: 52px;
`;

const Status = styled.div`
  ${RobotoBoldBlack16px}
  position: absolute;
  width: 146px;
  top: 76px;
  left: 1014px;
  letter-spacing: 0;
  line-height: 20px;
  white-space: nowrap;
`;

const V2close = styled.img`
  position: absolute;
  width: 24px;
  height: 24px;
  top: 16px;
  left: 1112px;
`;

const Lines = styled.img`
  position: absolute;
  width: 1168px;
  height: 709px;
  top: 0;
  left: 0;
`;

export default X1ACostTabPrimaryNav;
