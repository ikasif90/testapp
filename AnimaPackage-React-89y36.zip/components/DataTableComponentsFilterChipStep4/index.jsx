import React from "react";
import styled from "styled-components";
import { RobotoNormalEerieBlack14px } from "../../styledMixins";


function DataTableComponentsFilterChipStep4(props) {
  const { chipTitle, filterSearch1 } = props;

  return (
    <Chip>
      <OverlapGroup2>
        <Chip1>
          <ChipTitle>{chipTitle}</ChipTitle>
          <I147301436314381 src="/img/-@2x.svg" />
          <FilterSearch1>{filterSearch1}</FilterSearch1>
          <OverlapGroup>
            <V2closeCircleOutline src="/img/v2-close-circle-outline@2x.svg" />
            <Rectangle></Rectangle>
          </OverlapGroup>
        </Chip1>
        <Rectangle1></Rectangle1>
        <Rectangle2></Rectangle2>
        <Padding></Padding>
        <Padding1></Padding1>
      </OverlapGroup2>
    </Chip>
  );
}

const Chip = styled.div`
  position: absolute;
  height: 44px;
  top: 1px;
  left: 49px;
  display: flex;
  justify-content: center;
  align-items: flex-start;
  min-width: 201px;
  border: 0px none;
`;

const OverlapGroup2 = styled.div`
  width: 203px;
  height: 46px;
  position: relative;
  margin-top: -1px;
`;

const Chip1 = styled.div`
  ${RobotoNormalEerieBlack14px}
  position: absolute;
  width: 185px;
  height: 28px;
  top: 17px;
  left: 9px;
  display: flex;
  padding: 0 9px;
  align-items: center;
  background-color: #ffffff61;
  border-radius: 14px;
  overflow: hidden;
  border: 1px solid;
  border-color: #102440;
`;

const ChipTitle = styled.div`
  min-height: 20px;
  margin-left: 2px;
  margin-bottom: 2px;
  min-width: 39px;
  letter-spacing: 0;
  line-height: 20px;
  white-space: nowrap;
`;

const I147301436314381 = styled.img`
  width: 2px;
  height: 9px;
  margin-left: 4px;
  margin-bottom: 0.45px;
`;

const FilterSearch1 = styled.div`
  min-height: 20px;
  margin-left: 6px;
  margin-bottom: 2px;
  min-width: 90px;
  letter-spacing: 0;
  line-height: 20px;
  white-space: nowrap;
`;

const OverlapGroup = styled.div`
  width: 21px;
  height: 28px;
  position: relative;
  margin-left: 3px;
`;

const V2closeCircleOutline = styled.img`
  position: absolute;
  width: 16px;
  height: 16px;
  top: 6px;
  left: 5px;
`;

const Rectangle = styled.div`
  position: absolute;
  width: 6px;
  height: 28px;
  top: 0;
  left: 0;
  border: 0px none;
`;

const Rectangle1 = styled.div`
  position: absolute;
  width: 10px;
  height: 46px;
  top: 0;
  left: 0;
  border: 0px none;
`;

const Rectangle2 = styled.div`
  position: absolute;
  width: 174px;
  height: 18px;
  top: 0;
  left: 8px;
  border: 0px none;
`;

const Padding = styled.div`
  position: absolute;
  width: 10px;
  height: 45px;
  top: 0;
  left: 0;
  border: 0px none;
`;

const Padding1 = styled.div`
  position: absolute;
  width: 10px;
  height: 45px;
  top: 0;
  left: 193px;
  border: 0px none;
`;

export default DataTableComponentsFilterChipStep4;
