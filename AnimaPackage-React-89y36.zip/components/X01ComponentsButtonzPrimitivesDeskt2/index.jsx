import React from "react";
import X100GlobalPrimitivesBasesInteractiv from "../X100GlobalPrimitivesBasesInteractiv";
import X01ComponentsButtonzPrimitivesLabel from "../X01ComponentsButtonzPrimitivesLabel";
import styled from "styled-components";


function X01ComponentsButtonzPrimitivesDeskt2(props) {
  const { x01ComponentsButtonzPrimitivesLabel } = props;

  return (
    <Type>
      <OverlapGroup>
        <X100GlobalPrimitivesBasesInteractiv />
        <X01ComponentsButtonzPrimitivesLabel>
          {x01ComponentsButtonzPrimitivesLabel.children}
        </X01ComponentsButtonzPrimitivesLabel>
      </OverlapGroup>
    </Type>
  );
}

const Type = styled.div`
  display: flex;
  align-items: flex-start;
  min-width: 155px;
  background-color: var(--absolute-zero);
  border-radius: 4px;
  border: 0px none;
`;

const OverlapGroup = styled.div`
  width: 155px;
  height: 46px;
  position: relative;
  border-radius: 4px;
`;

export default X01ComponentsButtonzPrimitivesDeskt2;
