import React from "react";
import styled from "styled-components";
import { RobotoNormalDoveGray12px } from "../../styledMixins";


function DataTablePaginationNumberOfPages(props) {
  const { children } = props;

  return (
    <DataTablePaginationNumberOfPages1>
      <OverlapGroup4>
        <X110Of100>{children}</X110Of100>
        <Rectangle></Rectangle>
        <Rectangle1></Rectangle1>
      </OverlapGroup4>
    </DataTablePaginationNumberOfPages1>
  );
}

const DataTablePaginationNumberOfPages1 = styled.div`
  height: 42px;
  display: flex;
  justify-content: center;
  align-items: flex-start;
  min-width: 76px;
  border: 0px none;
`;

const OverlapGroup4 = styled.div`
  width: 78px;
  height: 44px;
  position: relative;
  margin-top: -1px;
`;

const X110Of100 = styled.div`
  ${RobotoNormalDoveGray12px}
  position: absolute;
  width: 68px;
  top: 2px;
  left: 1px;
  text-align: right;
  letter-spacing: 0;
  line-height: 20px;
  white-space: nowrap;
`;

const Rectangle = styled.div`
  position: absolute;
  width: 10px;
  height: 22px;
  top: 0;
  left: 68px;
  border: 0px none;
`;

const Rectangle1 = styled.div`
  position: absolute;
  width: 78px;
  height: 24px;
  top: 20px;
  left: 0;
  border: 0px none;
`;

export default DataTablePaginationNumberOfPages;
