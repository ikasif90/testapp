import React from "react";
import X01ComponentsLinkRegular from "../X01ComponentsLinkRegular";
import styled from "styled-components";
import { RobotoBoldBlack16px } from "../../styledMixins";


function Group8(props) {
  const {
    x01ComponentsLinkRegular1Props,
    x01ComponentsLinkRegular2Props,
    x01ComponentsLinkRegular3Props,
    x01ComponentsLinkRegular4Props,
    x01ComponentsLinkRegular5Props,
    x01ComponentsLinkRegular6Props,
    x01ComponentsLinkRegular7Props,
    x01ComponentsLinkRegular8Props,
    x01ComponentsLinkRegular9Props,
    x01ComponentsLinkRegular10Props,
  } = props;

  return (
    <Group81>
      <Group5>
        <RequestName>Check Number</RequestName>
        <V2arrowDown src="/img/v2-arrow-down@2x.svg" />
      </Group5>
      <X01ComponentsLinkRegular
        x01ComponentsLinkzPrimitivesViewpor={x01ComponentsLinkRegular1Props.x01ComponentsLinkzPrimitivesViewpor}
      />
      <X01ComponentsLinkRegular
        className={x01ComponentsLinkRegular2Props.className}
        x01ComponentsLinkzPrimitivesViewpor={x01ComponentsLinkRegular2Props.x01ComponentsLinkzPrimitivesViewpor}
      />
      <X01ComponentsLinkRegular
        className={x01ComponentsLinkRegular3Props.className}
        x01ComponentsLinkzPrimitivesViewpor={x01ComponentsLinkRegular3Props.x01ComponentsLinkzPrimitivesViewpor}
      />
      <X01ComponentsLinkRegular
        className={x01ComponentsLinkRegular4Props.className}
        x01ComponentsLinkzPrimitivesViewpor={x01ComponentsLinkRegular4Props.x01ComponentsLinkzPrimitivesViewpor}
      />
      <X01ComponentsLinkRegular
        className={x01ComponentsLinkRegular5Props.className}
        x01ComponentsLinkzPrimitivesViewpor={x01ComponentsLinkRegular5Props.x01ComponentsLinkzPrimitivesViewpor}
      />
      <X01ComponentsLinkRegular
        className={x01ComponentsLinkRegular6Props.className}
        x01ComponentsLinkzPrimitivesViewpor={x01ComponentsLinkRegular6Props.x01ComponentsLinkzPrimitivesViewpor}
      />
      <X01ComponentsLinkRegular
        className={x01ComponentsLinkRegular7Props.className}
        x01ComponentsLinkzPrimitivesViewpor={x01ComponentsLinkRegular7Props.x01ComponentsLinkzPrimitivesViewpor}
      />
      <X01ComponentsLinkRegular
        className={x01ComponentsLinkRegular8Props.className}
        x01ComponentsLinkzPrimitivesViewpor={x01ComponentsLinkRegular8Props.x01ComponentsLinkzPrimitivesViewpor}
      />
      <X01ComponentsLinkRegular
        className={x01ComponentsLinkRegular9Props.className}
        x01ComponentsLinkzPrimitivesViewpor={x01ComponentsLinkRegular9Props.x01ComponentsLinkzPrimitivesViewpor}
      />
      <X01ComponentsLinkRegular
        className={x01ComponentsLinkRegular10Props.className}
        x01ComponentsLinkzPrimitivesViewpor={x01ComponentsLinkRegular10Props.x01ComponentsLinkzPrimitivesViewpor}
      />
    </Group81>
  );
}

const Group81 = styled.div`
  position: absolute;
  width: 165px;
  top: 76px;
  left: 33px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  min-height: 551px;
`;

const Group5 = styled.div`
  width: 131px;
  display: flex;
  align-items: flex-start;
  border: 0px none;
`;

const RequestName = styled.div`
  ${RobotoBoldBlack16px}
  min-height: 20px;
  min-width: 107px;
  letter-spacing: 0;
  line-height: 20px;
  white-space: nowrap;
`;

const V2arrowDown = styled.img`
  width: 20px;
  height: 20px;
  margin-left: 4px;
`;

export default Group8;
