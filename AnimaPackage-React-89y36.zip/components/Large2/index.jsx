import React from "react";
import PrimitivesmasterButton from "../PrimitivesmasterButton";
import styled from "styled-components";


function Large2(props) {
  const { primitivesmasterButtonProps } = props;

  return (
    <Large>
      <PrimitivesmasterButton>{primitivesmasterButtonProps.children}</PrimitivesmasterButton>
    </Large>
  );
}

const Large = styled.div`
  display: flex;
  width: fit-content;
  align-items: flex-start;
  position: absolute;
  top: 0;
  left: 128px;
  border: 1px none;
`;

export default Large2;
