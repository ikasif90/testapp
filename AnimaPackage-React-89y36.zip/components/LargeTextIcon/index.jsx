import React from "react";
import styled from "styled-components";


function LargeTextIcon(props) {
  const { children } = props;

  return (
    <FontOverridesHere>
      <Placeholder>{children}</Placeholder>
    </FontOverridesHere>
  );
}

const FontOverridesHere = styled.div`
  display: flex;
  width: fit-content;
  align-items: center;
  gap: 8px;
  border: 1px none;
`;

const Placeholder = styled.div`
  width: fit-content;
  margin-top: -1px;
  font-family: var(--font-family-fellix-regular);
  font-weight: 400;
  color: #00000099;
  font-size: 18px;
  letter-spacing: 0.27px;
  line-height: 24px;
  white-space: nowrap;
`;

export default LargeTextIcon;
