import React from "react";
import styled from "styled-components";


function V3BetaAccountAccountOutlined() {
  return (
    <V3BetaAccountIconsAccountOutlined>
      <Color src="/img/color@2x.svg" />
    </V3BetaAccountIconsAccountOutlined>
  );
}

const V3BetaAccountIconsAccountOutlined = styled.div`
  height: 32px;
  display: flex;
  padding: 0 4px;
  align-items: center;
  min-width: 32px;
  border: 0px none;
`;

const Color = styled.img`
  width: 24px;
  height: 24px;
`;

export default V3BetaAccountAccountOutlined;
