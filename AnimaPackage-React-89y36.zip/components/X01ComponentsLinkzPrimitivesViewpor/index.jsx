import React from "react";
import X01ComponentsLinkzPrimitivesLabelsD from "../X01ComponentsLinkzPrimitivesLabelsD";
import styled from "styled-components";


function X01ComponentsLinkzPrimitivesViewpor(props) {
  const { x01ComponentsLinkzPrimitivesLabelsD } = props;

  return (
    <DesktopMobile>
      <X01ComponentsLinkzPrimitivesLabelsD
        x01ComponentsLinkzPrimitivesLabelsD={x01ComponentsLinkzPrimitivesLabelsD.x01ComponentsLinkzPrimitivesLabelsD}
      />
    </DesktopMobile>
  );
}

const DesktopMobile = styled.div`
  height: 20px;
  position: relative;
  display: flex;
  align-items: flex-start;
  min-width: 61px;
  border: 0px none;
`;

export default X01ComponentsLinkzPrimitivesViewpor;
