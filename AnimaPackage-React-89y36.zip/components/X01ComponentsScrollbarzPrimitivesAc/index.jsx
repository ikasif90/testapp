import React from "react";
import styled from "styled-components";


function X01ComponentsScrollbarzPrimitivesAc() {
  return (
    <ActiveBar>
      <RectangleCopy6></RectangleCopy6>
    </ActiveBar>
  );
}

const ActiveBar = styled.div`
  height: 9px;
  display: flex;
  align-items: flex-start;
  min-width: 308px;
  border: 0px none;
`;

const RectangleCopy6 = styled.div`
  width: 282px;
  height: 4px;
  background-color: var(--absolute-zero);
  border-radius: 2px;
  border: 0px none;
`;

export default X01ComponentsScrollbarzPrimitivesAc;
