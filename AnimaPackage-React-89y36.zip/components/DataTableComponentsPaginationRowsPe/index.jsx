import React from "react";
import styled from "styled-components";
import { RobotoNormalEerieBlack14px } from "../../styledMixins";


function DataTableComponentsPaginationRowsPe(props) {
  const { number } = props;

  return (
    <DataTablePaginationRowsPerPage>
      <OverlapGroup1>
        <Rowsperpage src="/img/rowsperpage-@2x.svg" />
        <Path src="/img/path-1@2x.svg" />
        <Number>{number}</Number>
        <Rectangle></Rectangle>
        <Rectangle1></Rectangle1>
        <Rectangle2></Rectangle2>
        <Rectangle3></Rectangle3>
      </OverlapGroup1>
    </DataTablePaginationRowsPerPage>
  );
}

const DataTablePaginationRowsPerPage = styled.div`
  position: absolute;
  height: 60px;
  top: 649px;
  left: 0;
  display: flex;
  justify-content: center;
  align-items: flex-start;
  min-width: 146px;
  border: 0px none;
`;

const OverlapGroup1 = styled.div`
  width: 148px;
  height: 62px;
  position: relative;
  margin-top: -1px;
`;

const Rowsperpage = styled.img`
  position: absolute;
  width: 94px;
  height: 13px;
  top: 23px;
  left: 17px;
`;

const Path = styled.img`
  position: absolute;
  width: 8px;
  height: 4px;
  top: 26px;
  left: 139px;
`;

const Number = styled.div`
  ${RobotoNormalEerieBlack14px}
  position: absolute;
  width: 16px;
  top: 21px;
  left: 115px;
  letter-spacing: 0;
`;

const Rectangle = styled.div`
  position: absolute;
  width: 18px;
  height: 62px;
  top: 0;
  left: 0;
  border: 0px none;
`;

const Rectangle1 = styled.div`
  position: absolute;
  width: 132px;
  height: 26px;
  top: 36px;
  left: 16px;
  border: 0px none;
`;

const Rectangle2 = styled.div`
  position: absolute;
  width: 6px;
  height: 17px;
  top: 22px;
  left: 110px;
  border: 0px none;
`;

const Rectangle3 = styled.div`
  position: absolute;
  width: 10px;
  height: 17px;
  top: 22px;
  left: 130px;
  border: 0px none;
`;

export default DataTableComponentsPaginationRowsPe;
