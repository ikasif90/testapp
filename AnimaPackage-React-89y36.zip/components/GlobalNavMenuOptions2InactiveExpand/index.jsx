import React from "react";
import styled from "styled-components";


function GlobalNavMenuOptions2InactiveExpand() {
  return (
    <GlobalNavMenuOptions2InactiveExpand1>
      <ActiveBakground></ActiveBakground>
    </GlobalNavMenuOptions2InactiveExpand1>
  );
}

const GlobalNavMenuOptions2InactiveExpand1 = styled.div`
  height: 38px;
  display: flex;
  justify-content: center;
  align-items: flex-start;
  min-width: 113px;
  border: 0px none;
`;

const ActiveBakground = styled.div`
  width: 115px;
  height: 40px;
  margin-top: -1px;
  border-radius: 6px 6px 0px 0px;
  border: 0px none;
  opacity: 0.24;
`;

export default GlobalNavMenuOptions2InactiveExpand;
