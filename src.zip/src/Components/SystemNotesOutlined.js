import React from 'react'
import './SystemNotesOutlined.css'
export default function SystemNotesOutlined (props) {
	return (
		<div className={`SystemNotesOutlined_SystemNotesOutlined ${props.className}`}>
		</div>
	)
}