import React from 'react'
import './ThemeLightSizeMediumVariantGhostColorNeutralElevationFalseStateEnabled.css'
export default function ThemeLightSizeMediumVariantGhostColorNeutralElevationFalseStateEnabled (props) {
	return (
		<div className={`ThemeLightSizeMediumVariantGhostColorNeutralElevationFalseStateEnabled_ThemeLightSizeMediumVariantGhostColorNeutralElevationFalseStateEnabled ${props.className}`}>
		</div>
	)
}