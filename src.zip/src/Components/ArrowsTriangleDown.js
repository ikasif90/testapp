import React from 'react'
import './ArrowsTriangleDown.css'
export default function ArrowsTriangleDown (props) {
	return (
		<div className={`ArrowsTriangleDown_ArrowsTriangleDown ${props.className}`}>
		</div>
	)
}