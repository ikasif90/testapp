import React from 'react'
import './v3BetaAccountAccountOutlined.css'
export default function V3BetaAccountAccountOutlined (props) {
	return (
		<div className={`v3BetaAccountAccountOutlined_v3BetaAccountAccountOutlined ${props.className}`}>
		</div>
	)
}