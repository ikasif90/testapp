import React from 'react'
import './_primitivesMasterSearchLarge.css'
export default function _primitivesMasterSearchLarge (props) {
	return (
		<div className={`_primitivesMasterSearchLarge__primitivesMasterSearchLarge ${props.className}`}>
		</div>
	)
}