import React from 'react'
import './TokenBody1FontRobotoViewportDesktop.css'
export default function TokenBody1FontRobotoViewportDesktop (props) {
	return (
		<div className={`TokenBody1FontRobotoViewportDesktop_TokenBody1FontRobotoViewportDesktop ${props.className}`}>
		</div>
	)
}