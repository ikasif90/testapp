import React from 'react'
import './inputBase.css'
export default function InputBase (props) {
	return (
		<div className={`inputBase_inputBase ${props.className}`}>
		</div>
	)
}