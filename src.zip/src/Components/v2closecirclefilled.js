import React from 'react'
import './v2closecirclefilled.css'
export default function V2closecirclefilled (props) {
	return (
		<div className={`v2closecirclefilled_v2closecirclefilled ${props.className}`}>
		</div>
	)
}