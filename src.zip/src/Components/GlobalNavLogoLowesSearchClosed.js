import React from 'react'
import './GlobalNavLogoLowesSearchClosed.css'
export default function GlobalNavLogoLowesSearchClosed (props) {
	return (
		<div className={`GlobalNavLogoLowesSearchClosed_GlobalNavLogoLowesSearchClosed ${props.className}`}>
		</div>
	)
}