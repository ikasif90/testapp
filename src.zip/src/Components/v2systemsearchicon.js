import React from 'react'
import './v2systemsearchicon.css'
export default function V2systemsearchicon (props) {
	return (
		<div className={`v2systemsearchicon_v2systemsearchicon ${props.className}`}>
		</div>
	)
}