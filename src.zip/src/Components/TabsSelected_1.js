import React from 'react'
import './TabsSelected_1.css'
export default function TabsSelected_1 (props) {
	return (
		<div className={`TabsSelected_1_TabsSelected ${props.className}`}>
		</div>
	)
}