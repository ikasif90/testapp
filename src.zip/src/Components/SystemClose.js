import React from 'react'
import './SystemClose.css'
export default function SystemClose (props) {
	return (
		<div className={`SystemClose_SystemClose ${props.className}`}>
		</div>
	)
}