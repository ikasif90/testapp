import React from 'react'
import './v2arrowschevronleft.css'
export default function V2arrowschevronleft (props) {
	return (
		<div className={`v2arrowschevronleft_v2arrowschevronleft ${props.className}`}>
		</div>
	)
}