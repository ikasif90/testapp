import React from 'react'
import './DataTableComponentsFilterChipStep1.css'
export default function DataTableComponentsFilterChipStep1 (props) {
	return (
		<div className={`DataTableComponentsFilterChipStep1_DataTableComponentsFilterChipStep1 ${props.className}`}>
		</div>
	)
}