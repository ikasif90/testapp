import React from 'react'
import './_01ComponentsButtonzPrimitivesLabelsDesktopIconPrimaryNoicon.css'
export default function _01ComponentsButtonzPrimitivesLabelsDesktopIconPrimaryNoicon (props) {
	return (
		<div className={`_01ComponentsButtonzPrimitivesLabelsDesktopIconPrimaryNoicon__01ComponentsButtonzPrimitivesLabelsDesktopIconPrimaryNoicon ${props.className}`}>
		</div>
	)
}