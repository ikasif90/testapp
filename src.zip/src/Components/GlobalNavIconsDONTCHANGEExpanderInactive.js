import React from 'react'
import './GlobalNavIconsDONTCHANGEExpanderInactive.css'
export default function GlobalNavIconsDONTCHANGEExpanderInactive (props) {
	return (
		<div className={`GlobalNavIconsDONTCHANGEExpanderInactive_GlobalNavIconsDONTCHANGEExpanderInactive ${props.className}`}>
		</div>
	)
}