import React from 'react'
import './GlobalNavIconsDONTCHANGEProfileandIcons.css'
export default function GlobalNavIconsDONTCHANGEProfileandIcons (props) {
	return (
		<div className={`GlobalNavIconsDONTCHANGEProfileandIcons_GlobalNavIconsDONTCHANGEProfileandIcons ${props.className}`}>
		</div>
	)
}