import React from 'react'
import './DataTablePaginationPageNumberInactive.css'
export default function DataTablePaginationPageNumberInactive (props) {
	return (
		<div className={`DataTablePaginationPageNumberInactive_DataTablePaginationPageNumberInactive ${props.className}`}>
		</div>
	)
}