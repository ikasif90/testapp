import React from 'react'
import './DataTablePaginationButtonActive.css'
export default function DataTablePaginationButtonActive (props) {
	return (
		<div className={`DataTablePaginationButtonActive_DataTablePaginationButtonActive ${props.className}`}>
		</div>
	)
}