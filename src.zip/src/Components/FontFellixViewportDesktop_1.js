import React from 'react'
import './FontFellixViewportDesktop_1.css'
export default function FontFellixViewportDesktop_1 (props) {
	return (
		<div className={`FontFellixViewportDesktop_1_FontFellixViewportDesktop ${props.className}`}>
		</div>
	)
}