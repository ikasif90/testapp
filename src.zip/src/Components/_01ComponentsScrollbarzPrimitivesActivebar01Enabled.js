import React from 'react'
import './_01ComponentsScrollbarzPrimitivesActivebar01Enabled.css'
export default function _01ComponentsScrollbarzPrimitivesActivebar01Enabled (props) {
	return (
		<div className={`_01ComponentsScrollbarzPrimitivesActivebar01Enabled__01ComponentsScrollbarzPrimitivesActivebar01Enabled ${props.className}`}>
		</div>
	)
}