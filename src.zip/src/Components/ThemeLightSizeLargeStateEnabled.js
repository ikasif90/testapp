import React from 'react'
import './ThemeLightSizeLargeStateEnabled.css'
export default function ThemeLightSizeLargeStateEnabled (props) {
	return (
		<div className={`ThemeLightSizeLargeStateEnabled_ThemeLightSizeLargeStateEnabled ${props.className}`}>
		</div>
	)
}