import React from 'react'
import './_01ComponentsButtonzPrimitivesDesktopMediumPrimary.css'
export default function _01ComponentsButtonzPrimitivesDesktopMediumPrimary (props) {
	return (
		<div className={`_01ComponentsButtonzPrimitivesDesktopMediumPrimary__01ComponentsButtonzPrimitivesDesktopMediumPrimary ${props.className}`}>
		</div>
	)
}