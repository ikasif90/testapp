import React from 'react'
import './MobileFalseVariantSecondaryIconNoneColorInteractiveStateNormal.css'
export default function MobileFalseVariantSecondaryIconNoneColorInteractiveStateNormal (props) {
	return (
		<div className={`MobileFalseVariantSecondaryIconNoneColorInteractiveStateNormal_MobileFalseVariantSecondaryIconNoneColorInteractiveStateNormal ${props.className}`}>
		</div>
	)
}