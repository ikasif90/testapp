import React from 'react'
import './GlobalNavMenuOptions2InactiveExpanderOff.css'
export default function GlobalNavMenuOptions2InactiveExpanderOff (props) {
	return (
		<div className={`GlobalNavMenuOptions2InactiveExpanderOff_GlobalNavMenuOptions2InactiveExpanderOff ${props.className}`}>
		</div>
	)
}