import React from 'react'
import './v2arrowdown.css'
export default function V2arrowdown (props) {
	return (
		<div className={`v2arrowdown_v2arrowdown ${props.className}`}>
		</div>
	)
}