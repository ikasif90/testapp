import React from 'react'
import './_01ComponentsButtonzPrimitivesMediumDesktop.css'
export default function _01ComponentsButtonzPrimitivesMediumDesktop (props) {
	return (
		<div className={`_01ComponentsButtonzPrimitivesMediumDesktop__01ComponentsButtonzPrimitivesMediumDesktop ${props.className}`}>
		</div>
	)
}