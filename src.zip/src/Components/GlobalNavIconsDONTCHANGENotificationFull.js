import React from 'react'
import './GlobalNavIconsDONTCHANGENotificationFull.css'
export default function GlobalNavIconsDONTCHANGENotificationFull (props) {
	return (
		<div className={`GlobalNavIconsDONTCHANGENotificationFull_GlobalNavIconsDONTCHANGENotificationFull ${props.className}`}>
		</div>
	)
}