import React from 'react'
import './DataTableComponentsRowBackgroundWhite52.css'
export default function DataTableComponentsRowBackgroundWhite52 (props) {
	return (
		<div className={`DataTableComponentsRowBackgroundWhite52_DataTableComponentsRowBackgroundWhite52 ${props.className}`}>
		</div>
	)
}