import React from 'react'
import './SystemDocumentOutlined.css'
export default function SystemDocumentOutlined (props) {
	return (
		<div className={`SystemDocumentOutlined_SystemDocumentOutlined ${props.className}`}>
		</div>
	)
}