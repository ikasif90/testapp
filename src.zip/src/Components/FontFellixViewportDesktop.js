import React from 'react'
import './FontFellixViewportDesktop.css'
export default function FontFellixViewportDesktop (props) {
	return (
		<div className={`FontFellixViewportDesktop_FontFellixViewportDesktop ${props.className}`}>
		</div>
	)
}