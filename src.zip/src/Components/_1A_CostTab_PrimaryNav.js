import React from 'react'
import './_1A_CostTab_PrimaryNav.css'
import ImgAsset from '../public'
import {Link} from 'react-router-dom'
import Tabs from "./Tabs"
import GlobalNavMenuOptions2InactiveExpanderOff from "./GlobalNavMenuOptions2InactiveExpanderOff"
import TokenBody1FontRobotoViewportDesktop from "./TokenBody1FontRobotoViewportDesktop"
import GlobalNavIconsDONTCHANGEProfileandIcons from "./GlobalNavIconsDONTCHANGEProfileandIcons"
import GlobalNavLogoLowesSearchClosed from "./GlobalNavLogoLowesSearchClosed"
import _01ComponentsScrollbarzPrimitivesActivebar01Enabled from "./_01ComponentsScrollbarzPrimitivesActivebar01Enabled"
import _01ComponentsButton02Medium from "./_01ComponentsButton02Medium"
import MobileFalseVariantPrimaryIconNoneColorInteractiveStateNormal from "./MobileFalseVariantPrimaryIconNoneColorInteractiveStateNormal"
import MobileFalseVariantSecondaryIconNoneColorInteractiveStateNormal from "./MobileFalseVariantSecondaryIconNoneColorInteractiveStateNormal"
import ThemeLightSizeLargeStateEnabled_1 from "./ThemeLightSizeLargeStateEnabled_1"
import TokenBody1FontFellixViewportDesktop from "./TokenBody1FontFellixViewportDesktop"
import StyleText from "./StyleText"
import calendaroutline from "./calendaroutline"
import DataTableComponentsRowBackgroundWhite52 from "./DataTableComponentsRowBackgroundWhite52"
import v2arrowdown from "./v2arrowdown"
import _01ComponentsLinkRegular from "./_01ComponentsLinkRegular"
import v2close from "./v2close"
import DataTableComponentsPaginationRowsPerPage from "./DataTableComponentsPaginationRowsPerPage"
import DataTableComponentsFilterFull from "./DataTableComponentsFilterFull"
import DataTableComponentsFilterChipStep1 from "./DataTableComponentsFilterChipStep1"
import DataTablePagination from "./DataTablePagination"
import DataTableComponatsExport from "./DataTableComponatsExport"
import Tabs_1 from "./Tabs_1"
export default function _1A_CostTab_PrimaryNav () {
	return (
		<div className='_1A_CostTab_PrimaryNav__1A_CostTab_PrimaryNav'>
			<Tabs className='Tabs'/>
			<div className='Group2'>
				<div className='Rectangle'/>
				<div className='RectangleCopy'/>
			</div>
			<div className='GlobalNavMainNavVendorLowes'>
				<div className='HorizontalNavigationBackground'>
					<div className='GlobelNavComponantsBackgroundSubNavPopulatedOff'>
						<div className='Rectangle_1'/>
					</div>
					<div className='NavigationBackground'/>
					<div className='Rectangle_2'/>
				</div>
				<div className='MenuMain'>
					<img className='Path' src = {ImgAsset._1A_CostTab_PrimaryNav_Path} />
					<div className='Rectangle_3'/>
					<GlobalNavMenuOptions2InactiveExpanderOff className='GlobalNavMenuOptions2InactiveExpanderOff'/>
					<TokenBody1FontRobotoViewportDesktop className='ParagraphTextTextScale'/>
					<TokenBody1FontRobotoViewportDesktop className='ParagraphTextTextScale_1'/>
					<TokenBody1FontRobotoViewportDesktop className='ParagraphTextTextScale_2'/>
					<TokenBody1FontRobotoViewportDesktop className='ParagraphTextTextScale_3'/>
					<TokenBody1FontRobotoViewportDesktop className='ParagraphTextTextScale_4'/>
				</div>
				<GlobalNavIconsDONTCHANGEProfileandIcons className='ProfileandIcons'/>
				<GlobalNavLogoLowesSearchClosed className='GlobalNavLogoLowesSearchClosed'/>
				<img className='Rectangle416' src = {ImgAsset._1A_CostTab_PrimaryNav_Rectangle416} />
				<TokenBody1FontRobotoViewportDesktop className='ParagraphTextTextScale_5'/>
			</div>
			<img className='Rectangle_4' src = {ImgAsset._1A_CostTab_PrimaryNav_Rectangle_4} />
			<span className='helpertext'> </span>
			<div className='State'>
				<_01ComponentsScrollbarzPrimitivesActivebar01Enabled className='Activebar'/>
			</div>
			<TokenBody1FontRobotoViewportDesktop className='ParagraphTextTextScale_6'/>
			<_01ComponentsButton02Medium className='_01ComponentsButton01Large'/>
			<div className='Group10'>
				<span className='HomeOfficeVBU'>Home Office VBU</span>
				<span className='_456789'>456789</span>
			</div>
			<div className='Group10Copy'>
				<span className='PROGRAMTYPE'>PROGRAM TYPE</span>
				<span className='DropShip'>Drop-Ship</span>
			</div>
			<div className='Group13'>
				<span className='CurtainProLLC'>Curtain Pro, LLC</span>
				<span className='Welcome'>Welcome!</span>
			</div>
			<div className='Group12'>
				<div className='Group15'>
					<div className='Rectangle_5'/>
					<span className='CostChangeRequests'>Cost Change Requests</span>
					<MobileFalseVariantPrimaryIconNoneColorInteractiveStateNormal className='Large'/>
					<MobileFalseVariantSecondaryIconNoneColorInteractiveStateNormal className='Large_1'/>
					<span className='CostChangeRequests_1'>Search Checks</span>
					<ThemeLightSizeLargeStateEnabled_1 className='StandardSearch'/>
					<TokenBody1FontFellixViewportDesktop className='ParagraphTextTextScale_7'/>
					<div className='DateSelector'>
						<StyleText className='InputField'/>
						<StyleText className='InputField_1'/>
						<StyleText className='InputField_2'/>
						<div className='Frame826'>
							<calendaroutline className='calendaroutline'/>
						</div>
					</div>
				</div>
			</div>
			<div className='Group14'>
				<span className='Applications'>Vendor Finance Tools</span>
			</div>
			<div className='DataTableFullTableWithFilterandPaginationRows10NEW'>
				<DataTableComponentsRowBackgroundWhite52 className='DataTableComponentsRow13BackgroundWhite'/>
				<DataTableComponentsRowBackgroundWhite52 className='DataTableComponentsRow12BackgroundWhite'/>
				<DataTableComponentsRowBackgroundWhite52 className='DataTableComponentsRow11BackgroundWhite'/>
				<DataTableComponentsRowBackgroundWhite52 className='DataTableComponentsRow10BackgroundWhite'/>
				<DataTableComponentsRowBackgroundWhite52 className='DataTableComponentsRow8BackgroundWhite'/>
				<DataTableComponentsRowBackgroundWhite52 className='DataTableComponentsRow8BackgroundWhite_1'/>
				<DataTableComponentsRowBackgroundWhite52 className='DataTableComponentsRow7BackgroundWhite'/>
				<DataTableComponentsRowBackgroundWhite52 className='DataTableComponentsRow6BackgroundWhite'/>
				<DataTableComponentsRowBackgroundWhite52 className='DataTableComponentsRow5BackgroundWhite'/>
				<DataTableComponentsRowBackgroundWhite52 className='DataTableComponentsRow4BackgroundWhite'/>
				<DataTableComponentsRowBackgroundWhite52 className='DataTableComponentsRow3BackgroundWhite'/>
				<DataTableComponentsRowBackgroundWhite52 className='DataTableComponentsRow2BackgroundWhite'/>
				<div className='Group8'>
					<div className='Group5'>
						<span className='RequestName'>Check Number</span>
						<v2arrowdown className='v2arrowdown'/>
					</div>
					<_01ComponentsLinkRegular className='_01ComponentsLinkRegularCopy8'/>
					<_01ComponentsLinkRegular className='_01ComponentsLinkRegularCopy7'/>
					<_01ComponentsLinkRegular className='_01ComponentsLinkRegularCopy6'/>
					<_01ComponentsLinkRegular className='_01ComponentsLinkRegularCopy5'/>
					<_01ComponentsLinkRegular className='_01ComponentsLinkRegularCopy4'/>
					<_01ComponentsLinkRegular className='_01ComponentsLinkRegularCopy3'/>
					<_01ComponentsLinkRegular className='_01ComponentsLinkRegularCopy2'/>
					<_01ComponentsLinkRegular className='_01ComponentsLinkRegularCopy'/>
					<_01ComponentsLinkRegular className='_01ComponentsLinkRegular'/>
					<_01ComponentsLinkRegular className='_01ComponentsLinkRegular_1'/>
				</div>
				<div className='Group9'>
					<div className='Group5_1'>
						<span className='RequestName_1'>Check Number</span>
						<v2arrowdown className='v2arrowdown_1'/>
					</div>
					<_01ComponentsLinkRegular className='_01ComponentsLinkRegularCopy8_1'/>
					<_01ComponentsLinkRegular className='_01ComponentsLinkRegularCopy7_1'/>
					<_01ComponentsLinkRegular className='_01ComponentsLinkRegularCopy6_1'/>
					<_01ComponentsLinkRegular className='_01ComponentsLinkRegularCopy5_1'/>
					<_01ComponentsLinkRegular className='_01ComponentsLinkRegularCopy4_1'/>
					<_01ComponentsLinkRegular className='_01ComponentsLinkRegularCopy3_1'/>
					<_01ComponentsLinkRegular className='_01ComponentsLinkRegularCopy2_1'/>
					<_01ComponentsLinkRegular className='_01ComponentsLinkRegularCopy_1'/>
					<_01ComponentsLinkRegular className='_01ComponentsLinkRegular_2'/>
					<_01ComponentsLinkRegular className='_01ComponentsLinkRegular_3'/>
				</div>
				<div className='Group10_1'>
					<div className='Group5_2'>
						<span className='RequestName_2'>Invoice Number</span>
						<v2arrowdown className='v2arrowdown_2'/>
					</div>
					<_01ComponentsLinkRegular className='_01ComponentsLinkRegularCopy8_2'/>
					<_01ComponentsLinkRegular className='_01ComponentsLinkRegularCopy7_2'/>
					<_01ComponentsLinkRegular className='_01ComponentsLinkRegularCopy6_2'/>
					<_01ComponentsLinkRegular className='_01ComponentsLinkRegularCopy5_2'/>
					<_01ComponentsLinkRegular className='_01ComponentsLinkRegularCopy4_2'/>
					<_01ComponentsLinkRegular className='_01ComponentsLinkRegularCopy3_2'/>
					<_01ComponentsLinkRegular className='_01ComponentsLinkRegularCopy2_2'/>
					<_01ComponentsLinkRegular className='_01ComponentsLinkRegularCopy_2'/>
					<_01ComponentsLinkRegular className='_01ComponentsLinkRegular_4'/>
					<_01ComponentsLinkRegular className='_01ComponentsLinkRegular_5'/>
				</div>
				<div className='Group8_1'>
					<div className='Group5_3'>
						<span className='Request'>Paid Amount</span>
						<v2arrowdown className='v2arrowdown_3'/>
					</div>
					<span className='_12349950'>$99,999.99</span>
					<span className='_23434570'>$99,999.99</span>
					<span className='_23424576'>$99,999.99</span>
					<span className='_13345056'>$99,999.99</span>
					<span className='_012344567'>$99,999.99</span>
					<span className='_12349950_1'>$99,999.99</span>
					<span className='_23434570_1'>$99,999.99</span>
					<span className='_23424576_1'>$99,999.99</span>
					<span className='_13345056_1'>$99,999.99</span>
					<span className='_012344567_1'>$99,999.99</span>
				</div>
				<div className='Group8_2'>
					<div className='Group5_4'>
						<span className='DateSubmitted'>Check Date </span>
						<v2arrowdown className='v2arrowdown_4'/>
					</div>
					<span className='_01152021'>01/15/2021</span>
					<span className='_02042021'>02/04/2021</span>
					<span className='_06082021'>06/08/2021</span>
					<span className='_01152021_1'>01/15/2021</span>
					<span className='_06152021'>06/15/2021</span>
					<span className='_01152021_2'>01/15/2021</span>
					<span className='_01152021_3'>01/15/2021</span>
					<span className='_02042021_1'>02/04/2021</span>
					<span className='_06082021_1'>06/08/2021</span>
					<span className='_06152021_1'>06/15/2021</span>
				</div>
				<div className='Group8_3'>
					<div className='Group5_5'>
						<span className='ItemType'>Invoice Amount</span>
						<v2arrowdown className='v2arrowdown_5'/>
						<v2arrowdown className='v2arrowdown_6'/>
					</div>
					<span className='SOSOnline'>$99,999.99</span>
					<span className='SOSOnline_1'>$99,999.99</span>
					<span className='Stock'>$99,999.99</span>
					<span className='SOSOnline_2'>$99,999.99</span>
					<span className='SOSOnline_3'>$99,999.99</span>
					<span className='Stock_1'>$99,999.99</span>
					<span className='Stock_2'>$99,999.99</span>
					<span className='Stock_3'>$99,999.99</span>
					<span className='SOSOnline_4'>$99,999.99</span>
					<span className='SOSOnline_5'>$99,999.99</span>
				</div>
				<div className='Group8_4'>
					<div className='Group5_6'>
						<span className='LocationType'>Invoice Count</span>
						<v2arrowdown className='v2arrowdown_7'/>
					</div>
					<span className='Stock_4'>23</span>
					<span className='Stock_5'>2</span>
					<span className='OnlineOnly'>6</span>
					<span className='OnlineOnly_1'>221</span>
					<span className='Stock_6'>65</span>
					<span className='Stock_7'>33</span>
					<span className='OnlineOnly_2'>123</span>
					<span className='Stock_8'>300</span>
					<span className='Stock_9'>12</span>
					<span className='OnlineOnly_3'>3456</span>
				</div>
				<div className='Group8_5'>
					<span className='Submitted'>1933</span>
					<span className='Submitted_1'>1933</span>
					<span className='Submitted_2'>1933</span>
					<span className='Submitted_3'>1933</span>
					<span className='Submitted_4'>1933</span>
					<span className='Submitted_5'>1933</span>
					<span className='Draft'>1933</span>
					<span className='Draft_1'>1933</span>
					<span className='Draft_2'>1933</span>
					<span className='Draft_3'>1933</span>
				</div>
				<div className='Group5_7'>
					<v2arrowdown className='v2arrowdown_8'/>
				</div>
				<span className='Status'>Remit to Vendor</span>
				<DataTableComponentsRowBackgroundWhite52 className='DataTableComponentsRow1BackgroundWhite'/>
				<v2close className='v2close'/>
				<div className='Lines'>
					<div className='Rectangle_6'/>
					<div className='Rectangle_7'/>
					<div className='RectangleCopy23'/>
					<div className='RectangleCopy6'/>
					<div className='RectangleCopy7'/>
					<div className='RectangleCopy8'/>
					<div className='RectangleCopy9'/>
					<div className='RectangleCopy10'/>
					<div className='RectangleCopy7_1'/>
					<div className='RectangleCopy8_1'/>
					<div className='RectangleCopy9_1'/>
					<div className='RectangleCopy10_1'/>
					<div className='RectangleCopy10_2'/>
				</div>
				<DataTableComponentsPaginationRowsPerPage className='DataTablePaginationRowsPerPage'/>
				<DataTableComponentsFilterFull className='DataTableFilterIconandChip'/>
				<DataTableComponentsFilterChipStep1 className='DataTableComponentsFilterChipStep1'/>
				<DataTablePagination className='DataTablePagination'/>
				<DataTableComponatsExport className='DataTableComponatsExport'/>
			</div>
			<Tabs_1 className='Tabs_1'/>
		</div>
	)
}