import React from 'react'
import './TabsNormal_1.css'
export default function TabsNormal_1 (props) {
	return (
		<div className={`TabsNormal_1_TabsNormal ${props.className}`}>
		</div>
	)
}