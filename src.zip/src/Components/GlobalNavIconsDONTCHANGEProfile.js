import React from 'react'
import './GlobalNavIconsDONTCHANGEProfile.css'
export default function GlobalNavIconsDONTCHANGEProfile (props) {
	return (
		<div className={`GlobalNavIconsDONTCHANGEProfile_GlobalNavIconsDONTCHANGEProfile ${props.className}`}>
		</div>
	)
}