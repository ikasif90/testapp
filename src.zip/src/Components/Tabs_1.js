import React from 'react'
import './Tabs_1.css'
export default function Tabs_1 (props) {
	return (
		<div className={`Tabs_1_Tabs ${props.className}`}>
		</div>
	)
}