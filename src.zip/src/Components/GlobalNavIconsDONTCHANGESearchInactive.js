import React from 'react'
import './GlobalNavIconsDONTCHANGESearchInactive.css'
export default function GlobalNavIconsDONTCHANGESearchInactive (props) {
	return (
		<div className={`GlobalNavIconsDONTCHANGESearchInactive_GlobalNavIconsDONTCHANGESearchInactive ${props.className}`}>
		</div>
	)
}