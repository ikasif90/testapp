import React from 'react'
import './IconLibrarySystemclose.css'
export default function IconLibrarySystemclose (props) {
	return (
		<div className={`IconLibrarySystemclose_IconLibrarySystemclose ${props.className}`}>
		</div>
	)
}