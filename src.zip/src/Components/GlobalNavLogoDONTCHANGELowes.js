import React from 'react'
import './GlobalNavLogoDONTCHANGELowes.css'
export default function GlobalNavLogoDONTCHANGELowes (props) {
	return (
		<div className={`GlobalNavLogoDONTCHANGELowes_GlobalNavLogoDONTCHANGELowes ${props.className}`}>
		</div>
	)
}