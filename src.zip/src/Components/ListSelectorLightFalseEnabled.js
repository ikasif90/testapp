import React from 'react'
import './ListSelectorLightFalseEnabled.css'
export default function ListSelectorLightFalseEnabled (props) {
	return (
		<div className={`ListSelectorLightFalseEnabled_ListSelectorLightFalseEnabled ${props.className}`}>
		</div>
	)
}