import React from 'react'
import './caretdown.css'
export default function Caretdown (props) {
	return (
		<div className={`caretdown_caretdown ${props.className}`}>
		</div>
	)
}