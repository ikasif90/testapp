import React from 'react'
import './DataTableComponentsFilterChipStep4.css'
export default function DataTableComponentsFilterChipStep4 (props) {
	return (
		<div className={`DataTableComponentsFilterChipStep4_DataTableComponentsFilterChipStep4 ${props.className}`}>
		</div>
	)
}