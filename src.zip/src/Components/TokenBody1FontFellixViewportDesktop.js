import React from 'react'
import './TokenBody1FontFellixViewportDesktop.css'
export default function TokenBody1FontFellixViewportDesktop (props) {
	return (
		<div className={`TokenBody1FontFellixViewportDesktop_TokenBody1FontFellixViewportDesktop ${props.className}`}>
		</div>
	)
}