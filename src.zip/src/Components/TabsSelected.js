import React from 'react'
import './TabsSelected.css'
export default function TabsSelected (props) {
	return (
		<div className={`TabsSelected_TabsSelected ${props.className}`}>
		</div>
	)
}