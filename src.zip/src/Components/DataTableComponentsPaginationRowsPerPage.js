import React from 'react'
import './DataTableComponentsPaginationRowsPerPage.css'
export default function DataTableComponentsPaginationRowsPerPage (props) {
	return (
		<div className={`DataTableComponentsPaginationRowsPerPage_DataTableComponentsPaginationRowsPerPage ${props.className}`}>
		</div>
	)
}