import React from 'react'
import './v2arrowschevronright.css'
export default function V2arrowschevronright (props) {
	return (
		<div className={`v2arrowschevronright_v2arrowschevronright ${props.className}`}>
		</div>
	)
}