import React from 'react'
import './_01ComponentsLinkzPrimitivesViewportRegularDesktop.css'
export default function _01ComponentsLinkzPrimitivesViewportRegularDesktop (props) {
	return (
		<div className={`_01ComponentsLinkzPrimitivesViewportRegularDesktop__01ComponentsLinkzPrimitivesViewportRegularDesktop ${props.className}`}>
		</div>
	)
}