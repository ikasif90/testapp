import React from 'react'
import './IconSizeDesktopSM.css'
export default function IconSizeDesktopSM (props) {
	return (
		<div className={`IconSizeDesktopSM_IconSizeDesktopSM ${props.className}`}>
		</div>
	)
}