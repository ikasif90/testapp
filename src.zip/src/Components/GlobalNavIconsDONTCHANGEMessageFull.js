import React from 'react'
import './GlobalNavIconsDONTCHANGEMessageFull.css'
export default function GlobalNavIconsDONTCHANGEMessageFull (props) {
	return (
		<div className={`GlobalNavIconsDONTCHANGEMessageFull_GlobalNavIconsDONTCHANGEMessageFull ${props.className}`}>
		</div>
	)
}