import React from 'react'
import './DataTablePaginationNumberofPages.css'
export default function DataTablePaginationNumberofPages (props) {
	return (
		<div className={`DataTablePaginationNumberofPages_DataTablePaginationNumberofPages ${props.className}`}>
		</div>
	)
}