import React from 'react'
import './MobileFalseVariantPrimaryIconNoneColorInteractiveStateNormal.css'
export default function MobileFalseVariantPrimaryIconNoneColorInteractiveStateNormal (props) {
	return (
		<div className={`MobileFalseVariantPrimaryIconNoneColorInteractiveStateNormal_MobileFalseVariantPrimaryIconNoneColorInteractiveStateNormal ${props.className}`}>
		</div>
	)
}