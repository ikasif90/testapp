import React from 'react'
import './DataTableComponentsFilterCloseIcon.css'
export default function DataTableComponentsFilterCloseIcon (props) {
	return (
		<div className={`DataTableComponentsFilterCloseIcon_DataTableComponentsFilterCloseIcon ${props.className}`}>
		</div>
	)
}