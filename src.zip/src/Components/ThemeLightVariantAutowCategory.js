import React from 'react'
import './ThemeLightVariantAutowCategory.css'
export default function ThemeLightVariantAutowCategory (props) {
	return (
		<div className={`ThemeLightVariantAutowCategory_ThemeLightVariantAutowCategory ${props.className}`}>
		</div>
	)
}