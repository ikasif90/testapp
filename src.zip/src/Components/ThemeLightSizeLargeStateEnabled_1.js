import React from 'react'
import './ThemeLightSizeLargeStateEnabled_1.css'
export default function ThemeLightSizeLargeStateEnabled_1 (props) {
	return (
		<div className={`ThemeLightSizeLargeStateEnabled_1_ThemeLightSizeLargeStateEnabled ${props.className}`}>
		</div>
	)
}