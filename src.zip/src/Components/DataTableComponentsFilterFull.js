import React from 'react'
import './DataTableComponentsFilterFull.css'
export default function DataTableComponentsFilterFull (props) {
	return (
		<div className={`DataTableComponentsFilterFull_DataTableComponentsFilterFull ${props.className}`}>
		</div>
	)
}