import React from 'react'
import './FontFellix.css'
export default function FontFellix (props) {
	return (
		<div className={`FontFellix_FontFellix ${props.className}`}>
		</div>
	)
}