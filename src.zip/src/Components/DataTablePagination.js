import React from 'react'
import './DataTablePagination.css'
export default function DataTablePagination (props) {
	return (
		<div className={`DataTablePagination_DataTablePagination ${props.className}`}>
		</div>
	)
}