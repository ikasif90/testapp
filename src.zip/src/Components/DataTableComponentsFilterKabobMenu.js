import React from 'react'
import './DataTableComponentsFilterKabobMenu.css'
export default function DataTableComponentsFilterKabobMenu (props) {
	return (
		<div className={`DataTableComponentsFilterKabobMenu_DataTableComponentsFilterKabobMenu ${props.className}`}>
		</div>
	)
}