import React from 'react'
import './DataTableComponatsExport.css'
export default function DataTableComponatsExport (props) {
	return (
		<div className={`DataTableComponatsExport_DataTableComponatsExport ${props.className}`}>
		</div>
	)
}