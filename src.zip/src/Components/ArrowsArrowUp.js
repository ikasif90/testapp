import React from 'react'
import './ArrowsArrowUp.css'
export default function ArrowsArrowUp (props) {
	return (
		<div className={`ArrowsArrowUp_ArrowsArrowUp ${props.className}`}>
		</div>
	)
}