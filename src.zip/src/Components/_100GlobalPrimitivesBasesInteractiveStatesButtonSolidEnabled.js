import React from 'react'
import './_100GlobalPrimitivesBasesInteractiveStatesButtonSolidEnabled.css'
export default function _100GlobalPrimitivesBasesInteractiveStatesButtonSolidEnabled (props) {
	return (
		<div className={`_100GlobalPrimitivesBasesInteractiveStatesButtonSolidEnabled__100GlobalPrimitivesBasesInteractiveStatesButtonSolidEnabled ${props.className}`}>
		</div>
	)
}