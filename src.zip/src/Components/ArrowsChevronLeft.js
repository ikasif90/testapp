import React from 'react'
import './ArrowsChevronLeft.css'
export default function ArrowsChevronLeft (props) {
	return (
		<div className={`ArrowsChevronLeft_ArrowsChevronLeft ${props.className}`}>
		</div>
	)
}