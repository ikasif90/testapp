import React from 'react'
import './SizeMedium.css'
export default function SizeMedium (props) {
	return (
		<div className={`SizeMedium_SizeMedium ${props.className}`}>
		</div>
	)
}