import React from 'react'
import './DataTableComponentsFilterIcon.css'
export default function DataTableComponentsFilterIcon (props) {
	return (
		<div className={`DataTableComponentsFilterIcon_DataTableComponentsFilterIcon ${props.className}`}>
		</div>
	)
}