import React from 'react'
import './_01ComponentsLinkRegular.css'
export default function _01ComponentsLinkRegular (props) {
	return (
		<div className={`_01ComponentsLinkRegular__01ComponentsLinkRegular ${props.className}`}>
		</div>
	)
}