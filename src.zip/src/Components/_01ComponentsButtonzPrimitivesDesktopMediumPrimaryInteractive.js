import React from 'react'
import './_01ComponentsButtonzPrimitivesDesktopMediumPrimaryInteractive.css'
export default function _01ComponentsButtonzPrimitivesDesktopMediumPrimaryInteractive (props) {
	return (
		<div className={`_01ComponentsButtonzPrimitivesDesktopMediumPrimaryInteractive__01ComponentsButtonzPrimitivesDesktopMediumPrimaryInteractive ${props.className}`}>
		</div>
	)
}