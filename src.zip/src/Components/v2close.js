import React from 'react'
import './v2close.css'
export default function V2close (props) {
	return (
		<div className={`v2close_v2close ${props.className}`}>
		</div>
	)
}