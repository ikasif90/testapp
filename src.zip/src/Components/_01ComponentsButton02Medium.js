import React from 'react'
import './_01ComponentsButton02Medium.css'
export default function _01ComponentsButton02Medium (props) {
	return (
		<div className={`_01ComponentsButton02Medium__01ComponentsButton02Medium ${props.className}`}>
		</div>
	)
}