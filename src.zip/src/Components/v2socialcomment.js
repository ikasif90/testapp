import React from 'react'
import './v2socialcomment.css'
export default function V2socialcomment (props) {
	return (
		<div className={`v2socialcomment_v2socialcomment ${props.className}`}>
		</div>
	)
}