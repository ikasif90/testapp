import React from 'react'
import './calendaroutline.css'
export default function Calendaroutline (props) {
	return (
		<div className={`calendaroutline_calendaroutline ${props.className}`}>
		</div>
	)
}