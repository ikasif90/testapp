import React from 'react'
import './Tabs.css'
export default function Tabs (props) {
	return (
		<div className={`Tabs_Tabs ${props.className}`}>
		</div>
	)
}