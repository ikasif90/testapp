import React from 'react'
import './_primitivesmasterbutton.css'
export default function _primitivesmasterbutton (props) {
	return (
		<div className={`_primitivesmasterbutton__primitivesmasterbutton ${props.className}`}>
		</div>
	)
}