import React from 'react'
import './_primitivesMasterlistselector.css'
export default function _primitivesMasterlistselector (props) {
	return (
		<div className={`_primitivesMasterlistselector__primitivesMasterlistselector ${props.className}`}>
		</div>
	)
}