import React from 'react'
import './_01ComponentsLinkzPrimitivesUnderlineTransparent.css'
export default function _01ComponentsLinkzPrimitivesUnderlineTransparent (props) {
	return (
		<div className={`_01ComponentsLinkzPrimitivesUnderlineTransparent__01ComponentsLinkzPrimitivesUnderlineTransparent ${props.className}`}>
		</div>
	)
}