import React from 'react'
import './v3BetaSystemPlus.css'
export default function V3BetaSystemPlus (props) {
	return (
		<div className={`v3BetaSystemPlus_v3BetaSystemPlus ${props.className}`}>
		</div>
	)
}