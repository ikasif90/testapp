import React from 'react'
import './StyleText.css'
export default function StyleText (props) {
	return (
		<div className={`StyleText_StyleText ${props.className}`}>
		</div>
	)
}