import React from 'react'
import './SystemSearchIcon.css'
export default function SystemSearchIcon (props) {
	return (
		<div className={`SystemSearchIcon_SystemSearchIcon ${props.className}`}>
		</div>
	)
}