import React from 'react'
import './_primitivesMediummasterbutton.css'
export default function _primitivesMediummasterbutton (props) {
	return (
		<div className={`_primitivesMediummasterbutton__primitivesMediummasterbutton ${props.className}`}>
		</div>
	)
}