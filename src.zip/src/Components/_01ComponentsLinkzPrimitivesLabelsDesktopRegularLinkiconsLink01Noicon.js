import React from 'react'
import './_01ComponentsLinkzPrimitivesLabelsDesktopRegularLinkiconsLink01Noicon.css'
export default function _01ComponentsLinkzPrimitivesLabelsDesktopRegularLinkiconsLink01Noicon (props) {
	return (
		<div className={`_01ComponentsLinkzPrimitivesLabelsDesktopRegularLinkiconsLink01Noicon__01ComponentsLinkzPrimitivesLabelsDesktopRegularLinkiconsLink01Noicon ${props.className}`}>
		</div>
	)
}