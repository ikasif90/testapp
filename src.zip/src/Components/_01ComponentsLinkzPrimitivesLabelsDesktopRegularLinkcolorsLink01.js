import React from 'react'
import './_01ComponentsLinkzPrimitivesLabelsDesktopRegularLinkcolorsLink01.css'
export default function _01ComponentsLinkzPrimitivesLabelsDesktopRegularLinkcolorsLink01 (props) {
	return (
		<div className={`_01ComponentsLinkzPrimitivesLabelsDesktopRegularLinkcolorsLink01__01ComponentsLinkzPrimitivesLabelsDesktopRegularLinkcolorsLink01 ${props.className}`}>
		</div>
	)
}