import React from 'react'
import './TabsNormal.css'
export default function TabsNormal (props) {
	return (
		<div className={`TabsNormal_TabsNormal ${props.className}`}>
		</div>
	)
}