import React from 'react'
import './_Nonfloated.css'
export default function _Nonfloated (props) {
	return (
		<div className={`_Nonfloated__Nonfloated ${props.className}`}>
		</div>
	)
}