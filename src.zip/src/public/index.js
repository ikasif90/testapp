
        const tryRequire = (path) => {
        	try {
        	const image = require(`${path}`);
        	return image
        	} catch (err) {
        	return false
        	}
        };

        export default {
        
	questionMark: require('./questionMark.png'),
	_1A_CostTab_PrimaryNav_Path: tryRequire('./_1A_CostTab_PrimaryNav_Path.png') || require('./questionMark.png'),
	_1A_CostTab_PrimaryNav_Rectangle416: tryRequire('./_1A_CostTab_PrimaryNav_Rectangle416.png') || require('./questionMark.png'),
	_1A_CostTab_PrimaryNav_Rectangle_4: tryRequire('./_1A_CostTab_PrimaryNav_Rectangle_4.png') || require('./questionMark.png'),
}